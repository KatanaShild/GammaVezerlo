Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public class GammaRamp
{
    [StructLayout(LayoutKind.Sequential)]
    public struct RAMP
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 256)]
        public ushort[] Red;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 256)]
        public ushort[] Green;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 256)]
        public ushort[] Blue;
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    public struct DISPLAY_DEVICE
    {
        public uint cb;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
        public string DeviceName;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
        public string DeviceString;
        public uint StateFlags;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
        public string DeviceID;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
        public string DeviceKey;
    }
    [DllImport("user32.dll")]
    public static extern bool EnumDisplayDevices(string lpDevice, uint iDevNum, ref DISPLAY_DEVICE lpDisplayDevice, uint dwFlags);
    [DllImport("gdi32.dll", CharSet = CharSet.Ansi)]
    public static extern IntPtr CreateDC(string lpszDriver, string lpszDevice, string lpszOutput, IntPtr lpInitData);
    [DllImport("gdi32.dll")]
    public static extern bool DeleteDC(IntPtr hdc);
    [DllImport("gdi32.dll")]
    public static extern bool SetDeviceGammaRamp(IntPtr hdc, ref RAMP lpRamp);
    [DllImport("user32.dll")]
    public static extern short GetAsyncKeyState(int vKey);

    public static void ApplyAll(RAMP ramp)
    {
        uint i = 0;
        while (true)
        {
            DISPLAY_DEVICE dev = new DISPLAY_DEVICE();
            dev.cb = (uint)Marshal.SizeOf(dev);
            if (!EnumDisplayDevices(null, i, ref dev, 0)) break;
            if ((dev.StateFlags & 1) != 0)
            {
                IntPtr hdc = CreateDC("DISPLAY", dev.DeviceName, null, IntPtr.Zero);
                if (hdc != IntPtr.Zero)
                {
                    SetDeviceGammaRamp(hdc, ref ramp);
                    DeleteDC(hdc);
                }
            }
            i++;
        }
    }
}
"@

function Apply([double]$g, [double]$b, [double]$s, [double]$t) {
    $ramp = New-Object GammaRamp+RAMP
    $warm = $t / 100.0
    $fact = @{ 'Red' = 1.0 + 0.20 * $warm; 'Green' = 1.0 - 0.10 * $warm; 'Blue' = 1.0 - 0.30 * $warm }
    foreach ($ch in 'Red','Green','Blue') {
        $arr = New-Object 'uint16[]' 256
        for ($i = 0; $i -lt 256; $i++) {
            $v = [Math]::Pow($i / 255.0, 1.0 / $g) * $b
            $v = $v - 0.5
            $v = $v * $s
            $v = $v + 0.5
            $v = $v * $fact[$ch]
            if ($v -lt 0.0) { $v = 0.0 }
            if ($v -gt 1.0) { $v = 1.0 }
            $arr[$i] = [uint16][Math]::Round($v * 65535)
        }
        $ramp.$ch = $arr
    }
    [GammaRamp]::ApplyAll($ramp)
}

$baseDir = $PSScriptRoot
if (-not $baseDir) { $baseDir = Split-Path -Parent $MyInvocation.MyCommand.Path }
$profDir = Join-Path $baseDir 'profilok'
if (-not (Test-Path $profDir)) { New-Item -ItemType Directory -Path $profDir | Out-Null }
$stateFile = Join-Path $baseDir 'allapot.txt'
$lastFile  = Join-Path $baseDir 'utolsoprofil.txt'

$form = New-Object System.Windows.Forms.Form
$form.Text = "Gamma Vezerlo"
$form.Size = New-Object System.Drawing.Size(420, 490)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedSingle"
$form.MaximizeBox = $false

function MakeLabel([string]$text, [int]$y) {
    $l = New-Object System.Windows.Forms.Label
    $l.Text = $text
    $l.Location = New-Object System.Drawing.Point(20, $y)
    $l.AutoSize = $true
    return $l
}

$labG = MakeLabel "Gamma: 1.2" 15
$sG = New-Object System.Windows.Forms.TrackBar
$sG.Minimum = 3; $sG.Maximum = 30; $sG.Value = 12
$sG.Location = New-Object System.Drawing.Point(20, 33); $sG.Width = 360

$labB = MakeLabel "Fenyero: 1.00" 85
$sB = New-Object System.Windows.Forms.TrackBar
$sB.Minimum = 10; $sB.Maximum = 100; $sB.Value = 100
$sB.Location = New-Object System.Drawing.Point(20, 103); $sB.Width = 360

$labS = MakeLabel "Szaturacio: 1.0" 155
$sS = New-Object System.Windows.Forms.TrackBar
$sS.Minimum = 2; $sS.Maximum = 20; $sS.Value = 10
$sS.Location = New-Object System.Drawing.Point(20, 173); $sS.Width = 360

$labT = MakeLabel "Szinhomeret (meleg <-> hideg): 0" 225
$sT = New-Object System.Windows.Forms.TrackBar
$sT.Minimum = -30; $sT.Maximum = 30; $sT.Value = 0
$sT.Location = New-Object System.Drawing.Point(20, 243); $sT.Width = 360

function MakeButton([string]$text, [int]$x, [int]$y, [int]$w) {
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $text
    $b.Location = New-Object System.Drawing.Point($x, $y)
    $b.Size = New-Object System.Drawing.Size($w, 30)
    return $b
}

$btnReset = MakeButton "Alapallapot" 20 305 110
$btnExit  = MakeButton "Kilepes" 270 305 110

$labProf = MakeLabel "Profilok:" 345

$combo = New-Object System.Windows.Forms.ComboBox
$combo.Location = New-Object System.Drawing.Point(20, 365)
$combo.Size = New-Object System.Drawing.Size(250, 25)
$combo.DropDownStyle = "DropDownList"

function Refresh-Profiles {
    $sel = $combo.SelectedItem
    $combo.Items.Clear()
    Get-ChildItem -Path $profDir -Filter *.prof -ErrorAction SilentlyContinue | ForEach-Object {
        [void]$combo.Items.Add($_.BaseName)
    }
    if ($sel -and $combo.Items.Contains($sel)) { $combo.SelectedItem = $sel }
    elseif ($combo.Items.Count -gt 0) { $combo.SelectedIndex = 0 }
}

$btnSave = MakeButton "Mentes" 20 398 80
$btnLoad = MakeButton "Betoltes" 110 398 80
$btnDel  = MakeButton "Torles" 200 398 80

$scriptUpdate = {
    $g = $sG.Value / 10.0
    $b = $sB.Value / 100.0
    $s = $sS.Value / 10.0
    $t = $sT.Value * 10
    $labG.Text = "Gamma: " + $g
    $labB.Text = "Fenyero: " + $b.ToString("0.00")
    $labS.Text = "Szaturacio: " + $s
    $labT.Text = "Szinhomeret (meleg <-> hideg): " + $t
    [void](Apply $g $b $s $t)
}

$sG.Add_ValueChanged($scriptUpdate)
$sB.Add_ValueChanged($scriptUpdate)
$sS.Add_ValueChanged($scriptUpdate)
$sT.Add_ValueChanged($scriptUpdate)

$btnReset.Add_Click({
    $sG.Value = 12; $sB.Value = 100; $sS.Value = 10; $sT.Value = 0
})

$btnSave.Add_Click({
    $form.Topmost = $false
    Add-Type -AssemblyName Microsoft.VisualBasic
    $name = [Microsoft.VisualBasic.Interaction]::InputBox("Profil neve:", "Profil mentese", "ujprofil")
    $form.Topmost = $true
    $form.Activate()
    if ($name) {
        $name = ($name -replace '[\\/:*?"<>|]', '_')
        $data = "$( $sG.Value );$( $sB.Value );$( $sS.Value );$( $sT.Value )"
        [IO.File]::WriteAllText((Join-Path $profDir ($name + '.prof')), $data)
        Refresh-Profiles
        $combo.SelectedItem = $name
        [IO.File]::WriteAllText($lastFile, $name)
    }
})

$btnLoad.Add_Click({
    if ($combo.SelectedItem) {
        $f = Join-Path $profDir ($combo.SelectedItem + '.prof')
        if (Test-Path $f) {
            $p = [IO.File]::ReadAllText($f).Split(';')
            $sG.Value = [int]$p[0]
            $sB.Value = [int]$p[1]
            $sS.Value = [int]$p[2]
            if ($p.Count -gt 3) { $sT.Value = [int]$p[3] } else { $sT.Value = 0 }
            [IO.File]::WriteAllText($lastFile, $combo.SelectedItem)
        }
    }
})

$btnDel.Add_Click({
    if ($combo.SelectedItem) {
        $f = Join-Path $profDir ($combo.SelectedItem + '.prof')
        if (Test-Path $f) { Remove-Item $f }
        Refresh-Profiles
    }
})

$form.Controls.AddRange(@(
    $labG, $sG, $labB, $sB, $labS, $sS, $labT, $sT,
    $btnReset, $btnExit, $labProf, $combo,
    $btnSave, $btnLoad, $btnDel
))
$form.Topmost = $true

# --- Indulas: utolso profil es allapot visszatoltese ---
if (Test-Path $stateFile) {
    $sp = [IO.File]::ReadAllText($stateFile).Split(';')
    if ($sp.Count -ge 4) {
        try {
            if ([int]$sp[0] -ge $sG.Minimum -and [int]$sp[0] -le $sG.Maximum) { $sG.Value = [int]$sp[0] }
            if ([int]$sp[1] -ge $sB.Minimum -and [int]$sp[1] -le $sB.Maximum) { $sB.Value = [int]$sp[1] }
            if ([int]$sp[2] -ge $sS.Minimum -and [int]$sp[2] -le $sS.Maximum) { $sS.Value = [int]$sp[2] }
            if ([int]$sp[3] -ge $sT.Minimum -and [int]$sp[3] -le $sT.Maximum) { $sT.Value = [int]$sp[3] }
        } catch { }
    }
} else {
    & $scriptUpdate
}

if (Test-Path $lastFile) {
    $lastName = [IO.File]::ReadAllText($lastFile)
    if ($lastName -and (Test-Path (Join-Path $profDir ($lastName + '.prof')))) {
        Refresh-Profiles
        $combo.SelectedItem = $lastName
    }
}

# --- Hotkey-k ---
$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 150
$timer.Add_Tick({
    $hk1 = [GammaRamp]::GetAsyncKeyState(0x47)      # G
    $hkU = [GammaRamp]::GetAsyncKeyState(0x26)      # Fel
    $hkD = [GammaRamp]::GetAsyncKeyState(0x28)      # Le
    $ctrl = ([GammaRamp]::GetAsyncKeyState(0x11) -band 0x8000) -ne 0
    $alt  = ([GammaRamp]::GetAsyncKeyState(0x12) -band 0x8000) -ne 0
    if ($ctrl -and $alt -and ($hk1 -band 1)) {
        if ($form.Visible) { $form.Hide() } else { $form.Show(); $form.Activate() }
    }
    if ($ctrl -and $alt -and ($hkU -band 1)) {
        if ($sB.Value -lt $sB.Maximum) { $sB.Value = $sB.Value + 5 }
    }
    if ($ctrl -and $alt -and ($hkD -band 1)) {
        if ($sB.Value -gt $sB.Minimum) { $sB.Value = $sB.Value - 5 }
    }
})
$timer.Start()

# --- Kilepes: allapot mentese ---
$form.Add_FormClosing({
    $data = "$( $sG.Value );$( $sB.Value );$( $sS.Value );$( $sT.Value )"
    [IO.File]::WriteAllText($stateFile, $data)
    [void](Apply 1.0 1.0 1.0 0)
})
$btnExit.Add_Click({ $form.Close() })

Add-Type -AssemblyName Microsoft.VisualBasic
Refresh-Profiles
[void]$form.ShowDialog()