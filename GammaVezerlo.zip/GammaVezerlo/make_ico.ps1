Add-Type -AssemblyName System.Drawing
$baseDir = $PSScriptRoot
if (-not $baseDir) { $baseDir = Split-Path -Parent $MyInvocation.MyCommand.Path }
$src = [System.Drawing.Image]::FromFile((Join-Path $baseDir 'ikon.png'))
$ico = Join-Path $baseDir 'gammagui.ico'
$ms  = New-Object System.IO.MemoryStream
$bmp32 = New-Object System.Drawing.Bitmap($src, 32, 32)
$bmp16 = New-Object System.Drawing.Bitmap($src, 16, 16)
$bw = New-Object System.IO.BinaryWriter($ms)
$bw.Write([uint16]0)
$bw.Write([uint16]1)
$bw.Write([uint16]2)
foreach ($b in @($bmp16, $bmp32)) {
    $ms2 = New-Object System.IO.MemoryStream
    $b.Save($ms2, [System.Drawing.Imaging.ImageFormat]::Png)
    $png = $ms2.ToArray()
    $bw.Write([byte]$b.Width)
    $bw.Write([byte]$b.Height)
    $bw.Write([byte]0)
    $bw.Write([byte]0)
    $bw.Write([uint16]1)
    $bw.Write([uint16]32)
    $bw.Write([uint32]$png.Length)
    $bw.Write([uint32]22)
    $bw.Write($png)
    $ms2.Dispose()
}
[System.IO.File]::WriteAllBytes($ico, $ms.ToArray())
$bw.Close()
$ms.Dispose()
$src.Dispose()
Write-Host 'Kesz: C:\GammaVezerlo\gammagui.ico' -ForegroundColor Green
