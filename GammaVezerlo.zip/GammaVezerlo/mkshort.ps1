$baseDir = $PSScriptRoot
if (-not $baseDir) { $baseDir = Split-Path -Parent $MyInvocation.MyCommand.Path }

$batPath = Join-Path $baseDir 'Gamma Vezerlo.bat'
$icoPath = Join-Path $baseDir 'gammagui.ico'
$desktop = [Environment]::GetFolderPath('Desktop')
$lnkPath = Join-Path $desktop 'Gamma Vezerlo.lnk'

Write-Host "Mappa:  $baseDir"
Write-Host "Bat:    $batPath   (letezik: $(Test-Path $batPath))"
Write-Host "Ikon:   $icoPath   (letezik: $(Test-Path $icoPath))"
Write-Host "Cel:    $lnkPath"

try {
    $ws = New-Object -ComObject WScript.Shell
    $lnk = $ws.CreateShortcut($lnkPath)
    $lnk.TargetPath = $batPath
    $lnk.WorkingDirectory = $baseDir
    $lnk.IconLocation = "$icoPath,0"
    $lnk.Description = 'Gamma/Fenyero/Szaturacio vezerlo'
    $lnk.Save()
    Write-Host ""
    Write-Host "OK - parancsikon elmentve." -ForegroundColor Green
} catch {
    Write-Host ""
    Write-Host "HIBA: $($_.Exception.Message)" -ForegroundColor Red
}
