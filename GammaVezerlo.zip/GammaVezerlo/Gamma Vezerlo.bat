@echo off
powershell -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0mkshort.ps1"
powershell -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0gammagui.ps1"