@echo off
setlocal
rem A Windowsba beepitett .NET Framework 4 C# forditojaval épít, semmit nem kell telepíteni.
set CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe
if not exist "%CSC%" set CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe
"%CSC%" /nologo /target:winexe /platform:anycpu /optimize+ /out:"%~dp0..\GammaVezerlo.exe" /win32icon:"%~dp0..\gammagui.ico" /win32manifest:"%~dp0app.manifest" /resource:"%~dp0..\gammagui.ico",GammaVezerlo.gammagui.ico /reference:System.dll /reference:System.Core.dll /reference:System.Drawing.dll /reference:System.Windows.Forms.dll "%~dp0Program.cs"
if errorlevel 1 (echo HIBA a forditasnal & pause) else (echo Kesz: ..\GammaVezerlo.exe & pause)
