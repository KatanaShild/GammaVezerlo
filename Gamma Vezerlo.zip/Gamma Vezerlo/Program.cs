﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;

[assembly: AssemblyTitle("Gamma Vezérlő")]
[assembly: AssemblyProduct("Gamma Vezérlő")]
[assembly: AssemblyDescription("Kijelző színbeállító: vibrance, szaturáció, gamma, fények/árnyékok")]
[assembly: AssemblyVersion("4.0.0.0")]
[assembly: AssemblyFileVersion("4.0.0.0")]



// ---------------- Gamma-gorbe (minden aktiv monitorra) ----------------
public static class GammaRamp
{
    [StructLayout(LayoutKind.Sequential)]
    public struct RAMP
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 256)] public ushort[] Red;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 256)] public ushort[] Green;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 256)] public ushort[] Blue;
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    public struct DISPLAY_DEVICE
    {
        public uint cb;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string DeviceName;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string DeviceString;
        public uint StateFlags;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string DeviceID;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string DeviceKey;
    }
    [DllImport("user32.dll")] static extern bool EnumDisplayDevices(string lpDevice, uint iDevNum, ref DISPLAY_DEVICE lpDisplayDevice, uint dwFlags);
    [DllImport("gdi32.dll", CharSet = CharSet.Ansi)] static extern IntPtr CreateDC(string lpszDriver, string lpszDevice, string lpszOutput, IntPtr lpInitData);
    [DllImport("gdi32.dll")] static extern bool DeleteDC(IntPtr hdc);
    [DllImport("gdi32.dll")] static extern bool SetDeviceGammaRamp(IntPtr hdc, ref RAMP lpRamp);

    // Parameterek: gam (1.0 = semleges), a tobbi -1..1
    // Az arnyalat (tint): pozitiv = meleg (piros+), negativ = hideg (kek+)
    public static ushort[][] BuildCurves(double gam, double hi, double sh, double bl, double wh, double shT, double hiT)
    {
        ushort[][] ch = new ushort[3][];
        for (int c = 0; c < 3; c++) ch[c] = new ushort[256];
        double[] prev = new double[3];
        for (int i = 0; i < 256; i++)
        {
            double x = i / 255.0;
            double xg = Math.Pow(x, 1.0 / Math.Max(0.1, gam));
            double mS = 6.75 * xg * (1 - xg) * (1 - xg);   // arnyek-maszk (csucs ~1/3-nal)
            double mH = 6.75 * xg * xg * (1 - xg);         // feny-maszk  (csucs ~2/3-nal)
            double y = xg;
            y += 0.30 * sh * mS + 0.30 * hi * mH;
            y += 0.15 * bl * Math.Pow(1 - xg, 3) + 0.15 * wh * xg * xg * xg;
            double tint = 0.08 * shT * (1 - xg) * (1 - xg) + 0.08 * hiT * xg * xg;
            double[] v = new double[] { y + tint, y, y - tint };
            for (int c = 0; c < 3; c++)
            {
                double val = Math.Max(0.0, Math.Min(1.0, v[c]));
                if (val < prev[c]) val = prev[c];          // monoton novekvo
                prev[c] = val;
                double u = val * 65535.0;
                // a Windows elutasitja a linearistol tul tavoli gorbeket -> korlatozzuk
                double lo = Math.Max(0.0, i * 257.0 - 120 * 256.0);
                double hiL = Math.Min(65535.0, i * 257.0 + 120 * 256.0);
                u = Math.Max(lo, Math.Min(hiL, u));
                ch[c][i] = (ushort)Math.Round(u);
            }
        }
        return ch;
    }

    public static void ApplyCurves(double gam, double hi, double sh, double bl, double wh, double shT, double hiT)
    {
        ushort[][] c = BuildCurves(gam, hi, sh, bl, wh, shT, hiT);
        RAMP ramp = new RAMP();
        ramp.Red = c[0]; ramp.Green = c[1]; ramp.Blue = c[2];
        uint i = 0;
        while (true)
        {
            DISPLAY_DEVICE dev = new DISPLAY_DEVICE();
            dev.cb = (uint)Marshal.SizeOf(dev);
            if (!EnumDisplayDevices(null, i, ref dev, 0)) break;
            if ((dev.StateFlags & 1) != 0)
            {
                IntPtr hdc = CreateDC("DISPLAY", dev.DeviceName, null, IntPtr.Zero);
                if (hdc != IntPtr.Zero) { SetDeviceGammaRamp(hdc, ref ramp); DeleteDC(hdc); }
            }
            i++;
        }
    }
}

// ---------------- Windows Magnification: fullscreen 5x5 szinmatrix ----------------
public static class Mag
{
    [StructLayout(LayoutKind.Sequential)]
    public struct MAGCOLOREFFECT
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 25)] public float[] transform;
    }
    [DllImport("Magnification.dll")] static extern bool MagInitialize();
    [DllImport("Magnification.dll")] static extern bool MagUninitialize();
    [DllImport("Magnification.dll")] static extern bool MagSetFullscreenColorEffect(ref MAGCOLOREFFECT e);

    static bool inited = false;
    public static string Status = "nincs inicializalva";

    public static bool Set(float[] m)
    {
        try
        {
            if (!inited) { inited = MagInitialize(); }
            if (!inited) { Status = "MagInitialize sikertelen"; return false; }
            MAGCOLOREFFECT e = new MAGCOLOREFFECT();
            e.transform = m;
            bool ok = MagSetFullscreenColorEffect(ref e);
            Status = ok ? "OK" : "MagSetFullscreenColorEffect sikertelen";
            return ok;
        }
        catch (Exception ex) { Status = ex.Message; return false; }
    }
    public static void Shutdown()
    {
        try
        {
            if (inited)
            {
                float[] id = new float[] { 1,0,0,0,0, 0,1,0,0,0, 0,0,1,0,0, 0,0,0,1,0, 0,0,0,0,1 };
                Set(id);
                MagUninitialize();
                inited = false;
            }
        }
        catch (Exception) { }
    }
}

// ---------------- NVIDIA NVAPI: Digital Vibrance ----------------
public static class Nv
{
    [DllImport("nvapi64.dll", EntryPoint = "nvapi_QueryInterface", CallingConvention = CallingConvention.Cdecl)]
    static extern IntPtr QI64(uint id);
    [DllImport("nvapi.dll", EntryPoint = "nvapi_QueryInterface", CallingConvention = CallingConvention.Cdecl)]
    static extern IntPtr QI32(uint id);
    static IntPtr QI(uint id) { return IntPtr.Size == 8 ? QI64(id) : QI32(id); }

    [StructLayout(LayoutKind.Sequential)]
    public struct DVC { public uint version; public int current; public int min; public int max; public int def; }

    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int D_Init();
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int D_Enum(uint idx, out IntPtr h);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int D_Get3(IntPtr h, uint outId, ref DVC i);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int D_Get2(IntPtr h, ref DVC i);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int D_Set3(IntPtr h, uint outId, ref DVC i);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int D_Set2(IntPtr h, ref DVC i);

    static T Fn<T>(uint id) where T : class
    {
        IntPtr p = QI(id);
        if (p == IntPtr.Zero) return null;
        return (T)(object)Marshal.GetDelegateForFunctionPointer(p, typeof(T));
    }

    const uint ID_Init = 0x0150E828, ID_Enum = 0x9ABDD40D, ID_GetEx = 0x0E45002D, ID_SetEx = 0x4A82C2B1;
    const uint VER = 20 | (1u << 16);

    static List<IntPtr> handles = new List<IntPtr>();
    static List<DVC> infos = new List<DVC>();
    static D_Set3 set3; static D_Set2 set2; static int setMode = 0;
    public static string Status = "nincs inicializalva";
    public static bool Available = false;
    public static int Count { get { return handles.Count; } }
    public static int DefaultPercent = 50;

    public static bool Init()
    {
        try
        {
            D_Init init = Fn<D_Init>(ID_Init);
            if (init == null) { Status = "NVAPI nem található"; return false; }
            int r = init();
            if (r != 0) { Status = "NvAPI_Initialize hiba: " + r; return false; }
            D_Enum en = Fn<D_Enum>(ID_Enum);
            D_Get3 get3 = Fn<D_Get3>(ID_GetEx);
            D_Get2 get2 = Fn<D_Get2>(ID_GetEx);
            set3 = Fn<D_Set3>(ID_SetEx);
            set2 = Fn<D_Set2>(ID_SetEx);
            if (en == null || get3 == null) { Status = "NVAPI fuggvenyek hianyoznak"; return false; }
            int enumCount = 0, lastErr = 0;
            for (uint i = 0; i < 16; i++)
            {
                IntPtr h;
                if (en(i, out h) != 0) break;
                enumCount++;
                DVC info = new DVC(); info.version = VER;
                int gr = get3(h, 0, ref info);
                if (gr != 0) { info = new DVC(); info.version = VER; gr = get2(h, ref info); }
                if (gr == 0) { handles.Add(h); infos.Add(info); } else { lastErr = gr; }
            }
            if (handles.Count == 0)
            {
                Status = (enumCount == 0)
                    ? "NVIDIA kijelző nem található · szoftveres vibrance"
                    : "NVIDIA vibrance nem elérhető (kód: " + lastErr + ") · szoftveres";
                return false;
            }
            DVC f = infos[0];
            if (f.max > f.min) DefaultPercent = (int)Math.Round((f.def - f.min) * 100.0 / (f.max - f.min));
            Available = true;
            Status = "NVIDIA driver OK (" + handles.Count + " kijelző)";
            return true;
        }
        catch (DllNotFoundException) { Status = "Nincs NVIDIA driver · szoftveres vibrance"; return false; }
        catch (Exception ex) { Status = ex.Message; return false; }
    }

    static bool SetLevel(int idx, int level)
    {
        DVC info = infos[idx]; info.current = level; info.version = VER;
        IntPtr h = handles[idx];
        if (setMode != 2 && set3 != null)
        {
            if (set3(h, 0, ref info) == 0) { setMode = 3; return true; }
        }
        if (setMode != 3 && set2 != null)
        {
            if (set2(h, ref info) == 0) { setMode = 2; return true; }
        }
        return false;
    }

    public static bool SetPercent(int pct)
    {
        if (!Available) return false;
        if (pct < 0) pct = 0;
        if (pct > 100) pct = 100;
        bool any = false;
        for (int i = 0; i < handles.Count; i++)
        {
            DVC f = infos[i];
            int lvl = f.min + (int)Math.Round(pct / 100.0 * (f.max - f.min));
            if (SetLevel(i, lvl)) any = true;
        }
        return any;
    }

    public static void Restore()
    {
        if (!Available) return;
        for (int i = 0; i < handles.Count; i++) SetLevel(i, infos[i].current);
    }
}

// ---------------- Globalis hotkey ----------------
public class HotKeyWindow : NativeWindow, IDisposable
{
    [DllImport("user32.dll")] static extern bool RegisterHotKey(IntPtr hWnd, int id, uint mods, uint vk);
    [DllImport("user32.dll")] static extern bool UnregisterHotKey(IntPtr hWnd, int id);
    public event Action<int> Pressed;
    public HotKeyWindow() { CreateHandle(new CreateParams()); }
    public bool Register(int id, uint mods, uint vk) { return RegisterHotKey(Handle, id, mods, vk); }
    protected override void WndProc(ref Message m)
    {
        if (m.Msg == 0x0312 && Pressed != null) Pressed(m.WParam.ToInt32());
        base.WndProc(ref m);
    }
    public void Dispose()
    {
        for (int i = 1; i <= 16; i++) UnregisterHotKey(Handle, i);
        DestroyHandle();
    }
}

// ---------------- Tema + sajat kontrollok (fekete / piros) ----------------
public static class Theme
{
    public static readonly Color Bg      = Color.FromArgb(10, 10, 12);
    public static readonly Color Card    = Color.FromArgb(20, 20, 23);
    public static readonly Color Card2   = Color.FromArgb(30, 30, 34);
    public static readonly Color Border  = Color.FromArgb(40, 40, 45);
    public static readonly Color Text    = Color.FromArgb(242, 242, 244);
    public static readonly Color Dim     = Color.FromArgb(135, 135, 143);
    public static readonly Color Accent  = Color.FromArgb(229, 32, 46);
    public static readonly Color AccentD = Color.FromArgb(150, 20, 30);
    public static readonly Color Track   = Color.FromArgb(44, 44, 50);

    [DllImport("dwmapi.dll")] static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int val, int size);
    public static void DarkTitle(IntPtr h)
    {
        try { int v = 1; if (DwmSetWindowAttribute(h, 20, ref v, 4) != 0) DwmSetWindowAttribute(h, 19, ref v, 4); }
        catch (Exception) { }
    }
}

public class Card : Panel
{
    public string Title = "";
    static Font fTitle = new Font("Segoe UI Semibold", 11f);
    public Card()
    {
        SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        BackColor = Theme.Card;
    }
    protected override void OnPaint(PaintEventArgs e)
    {
        Graphics g = e.Graphics;
        g.Clear(Theme.Bg);
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
        Rectangle r = new Rectangle(0, 0, Width - 1, Height - 1);
        int d = 24;
        using (GraphicsPath p = new GraphicsPath())
        {
            p.AddArc(r.X, r.Y, d, d, 180, 90);
            p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            p.CloseFigure();
            using (SolidBrush b = new SolidBrush(Theme.Card)) g.FillPath(b, p);
            using (Pen pen = new Pen(Theme.Border)) g.DrawPath(pen, p);
        }
        if (Title.Length > 0)
            using (SolidBrush tb = new SolidBrush(Theme.Text)) g.DrawString(Title, fTitle, tb, 20, 16);
    }
}

public class Slider : Control
{
    public int Minimum = 0, Maximum = 100, DefaultValue = 0, Step = 1;
    public string Caption = "", ValueText = "", Hint = "", Unit = "";
    public bool Big = false, FillFromDefault = false;
    public int[] MarkValues = null;
    public string[] MarkTexts = null;
    public event EventHandler ValueChanged;
    int val = 0; bool drag = false, hover = false;

    static Font fCap = new Font("Segoe UI", 9.5f);
    static Font fVal = new Font("Segoe UI Semibold", 9.5f);
    static Font fCapBig = new Font("Segoe UI Semibold", 11f);
    static Font fBig = new Font("Segoe UI Light", 27f);
    static Font fUnit = new Font("Segoe UI", 12f);
    static Font fSmall = new Font("Segoe UI", 8f);

    public Slider()
    {
        SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.Selectable, true);
        BackColor = Theme.Card;
        Cursor = Cursors.Hand;
    }

    public int Value
    {
        get { return val; }
        set
        {
            int v = Math.Max(Minimum, Math.Min(Maximum, value));
            if (v == val) return;
            val = v; Invalidate();
            if (ValueChanged != null) ValueChanged(this, EventArgs.Empty);
        }
    }

    float TrackY { get { return Big ? 82f : 38f; } }
    float PosX(int v) { float pad = 10f; return pad + (float)(v - Minimum) / (Maximum - Minimum) * (Width - 2 * pad); }
    int FromX(int x) { float pad = 10f; double t = (x - pad) / (Width - 2 * pad); return (int)Math.Round(Minimum + t * (Maximum - Minimum)); }

    protected override void OnPaint(PaintEventArgs e)
    {
        Graphics g = e.Graphics;
        g.Clear(BackColor);
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
        float ty = TrackY;
        using (SolidBrush white = new SolidBrush(Theme.Text))
        using (SolidBrush dim = new SolidBrush(Theme.Dim))
        {
            if (Big)
            {
                g.DrawString(Caption, fCapBig, white, 0, 0);
                SizeF hs = g.MeasureString(Hint, fSmall);
                g.DrawString(Hint, fSmall, dim, Width - hs.Width, 4);
                g.DrawString(ValueText, fBig, white, -3, 16);
                SizeF vs = g.MeasureString(ValueText, fBig);
                g.DrawString(Unit, fUnit, dim, vs.Width - 12, 40);
            }
            else
            {
                g.DrawString(Caption, fCap, dim, 0, 2);
                SizeF vs2 = g.MeasureString(ValueText, fVal);
                g.DrawString(ValueText, fVal, white, Width - vs2.Width + 2, 2);
            }
        }
        float x0 = PosX(FillFromDefault ? DefaultValue : Minimum);
        float x1 = PosX(val);
        using (Pen tp = new Pen(Theme.Track, 4f)) { tp.StartCap = LineCap.Round; tp.EndCap = LineCap.Round; g.DrawLine(tp, PosX(Minimum), ty, PosX(Maximum), ty); }
        if (Math.Abs(x1 - x0) > 0.5f)
            using (Pen fp = new Pen(Theme.Accent, 4f)) { fp.StartCap = LineCap.Round; fp.EndCap = LineCap.Round; g.DrawLine(fp, x0, ty, x1, ty); }
        // jelolok
        using (Pen mp = new Pen(Color.FromArgb(90, 90, 98), 1f))
        {
            if (MarkValues != null)
                for (int i = 0; i < MarkValues.Length; i++) { float mx = PosX(MarkValues[i]); g.DrawLine(mp, mx, ty - 7, mx, ty + 7); }
            else if (FillFromDefault)
            { float mx2 = PosX(DefaultValue); g.DrawLine(mp, mx2, ty - 7, mx2, ty + 7); }
        }
        if (Big && MarkTexts != null && MarkValues != null)
        {
            using (SolidBrush dim2 = new SolidBrush(Theme.Dim))
                for (int i = 0; i < MarkTexts.Length; i++)
                {
                    SizeF ms = g.MeasureString(MarkTexts[i], fSmall);
                    float mx = PosX(MarkValues[i]) - ms.Width / 2;
                    if (i == 0) mx = 2; else if (i == MarkTexts.Length - 1) mx = Width - ms.Width;
                    g.DrawString(MarkTexts[i], fSmall, dim2, mx, ty + 12);
                }
        }
        // fogantyu
        float tx = x1;
        if (drag || hover)
            using (SolidBrush ring = new SolidBrush(Color.FromArgb(70, Theme.Accent))) g.FillEllipse(ring, tx - 12, ty - 12, 24, 24);
        using (SolidBrush tb = new SolidBrush(Color.White)) g.FillEllipse(tb, tx - 8, ty - 8, 16, 16);
        using (Pen op = new Pen(drag ? Theme.Accent : Theme.AccentD, 2f)) g.DrawEllipse(op, tx - 8, ty - 8, 16, 16);
    }

    protected override void OnMouseDown(MouseEventArgs e) { if (e.Button == MouseButtons.Left) { drag = true; Capture = true; Value = FromX(e.X); Invalidate(); } base.OnMouseDown(e); }
    protected override void OnMouseMove(MouseEventArgs e) { if (drag) Value = FromX(e.X); base.OnMouseMove(e); }
    protected override void OnMouseUp(MouseEventArgs e) { drag = false; Capture = false; Invalidate(); base.OnMouseUp(e); }
    protected override void OnMouseEnter(EventArgs e)
    {
        hover = true; Invalidate();
        Form f = FindForm();
        if (!Focused && f != null && f.ContainsFocus) Focus();
        base.OnMouseEnter(e);
    }
    protected override bool IsInputKey(Keys keyData)
    {
        Keys k = keyData & Keys.KeyCode;
        if (k == Keys.Left || k == Keys.Right || k == Keys.Up || k == Keys.Down) return true;
        return base.IsInputKey(keyData);
    }
    protected override void OnKeyDown(KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Left || e.KeyCode == Keys.Down) { Value = val - Step; e.Handled = true; }
        else if (e.KeyCode == Keys.Right || e.KeyCode == Keys.Up) { Value = val + Step; e.Handled = true; }
        else if (e.KeyCode == Keys.Home) { Value = DefaultValue; e.Handled = true; }
        base.OnKeyDown(e);
    }
    protected override void OnMouseLeave(EventArgs e) { hover = false; Invalidate(); base.OnMouseLeave(e); }
    protected override void OnMouseDoubleClick(MouseEventArgs e) { Value = DefaultValue; base.OnMouseDoubleClick(e); }
    protected override void OnMouseWheel(MouseEventArgs e) { Value = val + (e.Delta > 0 ? Step : -Step); }
}

public class DarkList : ListBox
{
    public int BuiltIn = 0;
    static Font f = new Font("Segoe UI", 10.5f);
    public DarkList()
    {
        DrawMode = DrawMode.OwnerDrawFixed;
        ItemHeight = 36;
        BorderStyle = BorderStyle.None;
        BackColor = Theme.Card;
        ForeColor = Theme.Text;
        SetStyle(ControlStyles.OptimizedDoubleBuffer, true);
    }
    protected override void OnDrawItem(DrawItemEventArgs e)
    {
        if (e.Index < 0) return;
        bool sel = (e.State & DrawItemState.Selected) != 0;
        using (SolidBrush b = new SolidBrush(sel ? Color.FromArgb(38, 16, 20) : Theme.Card)) e.Graphics.FillRectangle(b, e.Bounds);
        if (sel) using (SolidBrush a = new SolidBrush(Theme.Accent)) e.Graphics.FillRectangle(a, e.Bounds.X, e.Bounds.Y + 4, 3, e.Bounds.Height - 8);
        if (e.Index == BuiltIn && BuiltIn > 0)
            using (Pen p = new Pen(Theme.Border)) e.Graphics.DrawLine(p, e.Bounds.X + 8, e.Bounds.Y, e.Bounds.Right - 8, e.Bounds.Y);
        Rectangle tr = new Rectangle(e.Bounds.X + 14, e.Bounds.Y, e.Bounds.Width - 14, e.Bounds.Height);
        TextRenderer.DrawText(e.Graphics, Items[e.Index].ToString(), f, tr, sel ? Theme.Text : Color.FromArgb(200, 200, 205), TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.EndEllipsis);
    }
}
// ================= Look-kod, mentes/betoltes (tiszta logika, nincs UI) =================
public static class LookCode
{
    public const int N = 12;
    public static readonly string[] Keys   = { "vib", "sat", "bri", "con", "hi", "bl", "sht", "gam", "tmp", "sh", "wh", "hit" };
    public static readonly string[] Titles = { "Vibrance", "Szaturáció", "Fényerő", "Kontraszt", "Fények", "Feketék", "Árnyék árnyalat", "Gamma", "Hőmérséklet", "Árnyékok", "Fehérek", "Fény árnyalat" };
    public static readonly int[] Mins  = { 0, 0, 20, 50, -100, -100, -100, 50, -100, -100, -100, -100 };
    public static readonly int[] Maxs  = { 350, 300, 150, 200, 100, 100, 100, 250, 100, 100, 100, 100 };
    public static readonly int[] Defs  = { 50, 100, 100, 100, 0, 0, 0, 100, 0, 0, 0, 0 };
    public static readonly int[] Steps = { 5, 5, 1, 1, 2, 2, 2, 1, 2, 2, 2, 2 };
    public static readonly bool[] Bi   = { false, false, true, true, true, true, true, true, true, true, true, true };

    public static int IndexOf(string key)
    {
        for (int i = 0; i < N; i++) if (Keys[i] == key) return i;
        return -1;
    }
    public static int Clamp(int i, int v) { return Math.Max(Mins[i], Math.Min(Maxs[i], v)); }

    static int Checksum(byte[] b)
    {
        int sum = 0;
        foreach (byte x in b) sum = (sum * 31 + x) & 0xFF;
        return sum;
    }

    public static string Encode(string name, int[] v)
    {
        string[] parts = new string[N];
        for (int i = 0; i < N; i++) parts[i] = v[i].ToString(CultureInfo.InvariantCulture);
        string payload = (name ?? "").Replace("|", "_") + "|" + string.Join(",", parts);
        byte[] b = Encoding.UTF8.GetBytes(payload);
        string s = Convert.ToBase64String(b).TrimEnd('=').Replace('+', '-').Replace('/', '_');
        return "GV1-" + s + "." + Checksum(b).ToString("x2");
    }

    static readonly Regex CodeRx = new Regex(@"GV1-([A-Za-z0-9_\-]+)\.([0-9a-fA-F]{2})");

    public static bool HasCode(string text)
    {
        return text != null && CodeRx.IsMatch(text);
    }

    public static bool Decode(string text, out string name, out int[] v)
    {
        name = null; v = null;
        if (text == null) return false;
        Match m = CodeRx.Match(text);
        if (!m.Success) return false;
        try
        {
            string s = m.Groups[1].Value.Replace('-', '+').Replace('_', '/');
            while (s.Length % 4 != 0) s += "=";
            byte[] b = Convert.FromBase64String(s);
            if (Checksum(b) != Convert.ToInt32(m.Groups[2].Value, 16)) return false;
            string payload = Encoding.UTF8.GetString(b);
            int bar = payload.IndexOf('|');
            if (bar < 0) return false;
            string[] parts = payload.Substring(bar + 1).Split(',');
            if (parts.Length != N) return false;
            int[] r = new int[N];
            for (int i = 0; i < N; i++) r[i] = Clamp(i, int.Parse(parts[i], CultureInfo.InvariantCulture));
            name = payload.Substring(0, bar);
            v = r;
            return true;
        }
        catch (Exception) { return false; }
    }

    public static string ToJson(int[] v)
    {
        StringBuilder sb = new StringBuilder();
        sb.Append("{\r\n");
        for (int i = 0; i < N; i++)
            sb.Append("  \"" + Keys[i] + "\": " + v[i].ToString(CultureInfo.InvariantCulture) + (i < N - 1 ? "," : "") + "\r\n");
        sb.Append("}");
        return sb.ToString();
    }

    // a v3-as PowerShell-es fajlok formatumaval is kompatibilis (lapos JSON)
    public static Dictionary<string, int> FromJson(string text)
    {
        Dictionary<string, int> d = new Dictionary<string, int>();
        foreach (Match m in Regex.Matches(text ?? "", "\"(\\w+)\"\\s*:\\s*(-?\\d+)"))
        {
            int val;
            if (int.TryParse(m.Groups[2].Value, NumberStyles.Integer, CultureInfo.InvariantCulture, out val)) d[m.Groups[1].Value] = val;
        }
        return d;
    }

    public static string SafeName(string name)
    {
        string n = Regex.Replace(name ?? "", "[\\\\/:*?\"<>|]", "_").Trim();
        return n;
    }
}

// ================= UI segedek =================
public static class UI
{
    public static Button MakeButton(string text, int x, int y, int w, int h, bool primary)
    {
        Button b = new Button();
        b.Text = text;
        b.Location = new Point(x, y);
        b.Size = new Size(w, h);
        b.FlatStyle = FlatStyle.Flat;
        b.UseVisualStyleBackColor = false;
        b.Cursor = Cursors.Hand;
        b.Font = new Font("Segoe UI Semibold", 9.5f);
        b.ForeColor = Theme.Text;
        b.FlatAppearance.BorderSize = 1;
        if (primary)
        {
            b.BackColor = Theme.Accent;
            b.FlatAppearance.BorderColor = Theme.Accent;
            b.FlatAppearance.MouseOverBackColor = Color.FromArgb(245, 60, 72);
        }
        else
        {
            b.BackColor = Theme.Card2;
            b.FlatAppearance.BorderColor = Theme.Border;
            b.FlatAppearance.MouseOverBackColor = Color.FromArgb(48, 48, 54);
        }
        return b;
    }

    public static Label MakeLabel(string text, int x, int y, Font font, Color color)
    {
        Label l = new Label();
        l.Text = text;
        l.AutoSize = true;
        l.Location = new Point(x, y);
        l.Font = font;
        l.ForeColor = color;
        l.BackColor = Color.Transparent;
        return l;
    }

    public static Icon LoadIcon(Size size)
    {
        try
        {
            using (Stream s = Assembly.GetExecutingAssembly().GetManifestResourceStream("GammaVezerlo.gammagui.ico"))
            {
                if (s == null) return SystemIcons.Application;
                return new Icon(s, size);
            }
        }
        catch (Exception) { return SystemIcons.Application; }
    }
}

public class DarkColors : ProfessionalColorTable
{
    static Color Sel = Color.FromArgb(52, 20, 26);
    public override Color ToolStripDropDownBackground { get { return Theme.Card; } }
    public override Color ImageMarginGradientBegin { get { return Theme.Card; } }
    public override Color ImageMarginGradientMiddle { get { return Theme.Card; } }
    public override Color ImageMarginGradientEnd { get { return Theme.Card; } }
    public override Color MenuBorder { get { return Theme.Border; } }
    public override Color MenuItemBorder { get { return Theme.Accent; } }
    public override Color MenuItemSelected { get { return Sel; } }
    public override Color MenuItemSelectedGradientBegin { get { return Sel; } }
    public override Color MenuItemSelectedGradientEnd { get { return Sel; } }
    public override Color MenuItemPressedGradientBegin { get { return Sel; } }
    public override Color MenuItemPressedGradientEnd { get { return Sel; } }
    public override Color SeparatorDark { get { return Theme.Border; } }
    public override Color SeparatorLight { get { return Theme.Border; } }
    public override Color CheckBackground { get { return Theme.AccentD; } }
    public override Color CheckSelectedBackground { get { return Theme.AccentD; } }
    public override Color CheckPressedBackground { get { return Theme.AccentD; } }
}

// ================= Sotet parbeszedablakok =================
public static class Dlg
{
    static Form Base(string title, int w)
    {
        Form f = new Form();
        f.Text = title;
        f.FormBorderStyle = FormBorderStyle.FixedDialog;
        f.StartPosition = FormStartPosition.CenterParent;
        f.MaximizeBox = false;
        f.MinimizeBox = false;
        f.ShowInTaskbar = false;
        f.TopMost = true;
        f.ClientSize = new Size(w, 100);
        f.BackColor = Theme.Bg;
        f.ForeColor = Theme.Text;
        f.Font = new Font("Segoe UI", 9.5f);
        f.HandleCreated += delegate { Theme.DarkTitle(f.Handle); };
        return f;
    }

    static Label AddText(Form f, string text, int y)
    {
        Size ls = TextRenderer.MeasureText(text, f.Font, new Size(f.ClientSize.Width - 40, 0), TextFormatFlags.WordBreak);
        Label l = new Label();
        l.AutoSize = false;
        l.Text = text;
        l.Location = new Point(20, y);
        l.Size = new Size(f.ClientSize.Width - 40, ls.Height + 2);
        l.ForeColor = Theme.Text;
        l.BackColor = Color.Transparent;
        f.Controls.Add(l);
        return l;
    }

    static TextBox AddBox(Form f, string text, int y, bool multi, bool readOnly)
    {
        TextBox tb = new TextBox();
        tb.Location = new Point(20, y);
        tb.Font = new Font("Segoe UI", 10f);
        tb.BackColor = Theme.Card2;
        tb.ForeColor = Theme.Text;
        tb.BorderStyle = BorderStyle.FixedSingle;
        tb.Multiline = multi;
        if (multi) { tb.ScrollBars = ScrollBars.Vertical; tb.Height = 86; }
        tb.Width = f.ClientSize.Width - 40;
        tb.ReadOnly = readOnly;
        tb.Text = text ?? "";
        f.Controls.Add(tb);
        return tb;
    }

    static void Finish(Form f, int y, Button b1, Button b2)
    {
        int w = f.ClientSize.Width;
        b2.Location = new Point(w - 20 - b2.Width, y);
        b1.Location = new Point(w - 20 - b2.Width - 10 - b1.Width, y);
        f.Controls.Add(b1); f.Controls.Add(b2);
        f.ClientSize = new Size(w, y + b1.Height + 18);
    }

    public static string Prompt(IWin32Window owner, string title, string label, string def, bool multi, string okText)
    {
        using (Form f = Base(title, 480))
        {
            Label l = AddText(f, label, 18);
            TextBox tb = AddBox(f, def, l.Bottom + 10, multi, false);
            Button ok = UI.MakeButton(okText, 0, 0, 130, 32, true); ok.DialogResult = DialogResult.OK;
            Button cancel = UI.MakeButton("Mégse", 0, 0, 100, 32, false); cancel.DialogResult = DialogResult.Cancel;
            Finish(f, tb.Bottom + 16, ok, cancel);
            if (!multi) f.AcceptButton = ok;
            f.CancelButton = cancel;
            f.Shown += delegate { tb.Focus(); tb.SelectAll(); };
            return f.ShowDialog(owner) == DialogResult.OK ? tb.Text.Trim() : null;
        }
    }

    public static void Info(IWin32Window owner, string title, string msg)
    {
        using (Form f = Base(title, 440))
        {
            Label l = AddText(f, msg, 20);
            Button ok = UI.MakeButton("OK", 0, 0, 100, 32, true); ok.DialogResult = DialogResult.OK;
            Button dummy = UI.MakeButton("", 0, 0, 0, 32, false);
            dummy.Visible = false;
            Finish(f, l.Bottom + 18, ok, dummy);
            f.AcceptButton = ok; f.CancelButton = ok;
            f.ShowDialog(owner);
        }
    }

    public static bool Confirm(IWin32Window owner, string title, string msg, string yes)
    {
        using (Form f = Base(title, 440))
        {
            Label l = AddText(f, msg, 20);
            Button ok = UI.MakeButton(yes, 0, 0, 120, 32, true); ok.DialogResult = DialogResult.OK;
            Button no = UI.MakeButton("Mégse", 0, 0, 100, 32, false); no.DialogResult = DialogResult.Cancel;
            Finish(f, l.Bottom + 18, ok, no);
            f.AcceptButton = ok; f.CancelButton = no;
            return f.ShowDialog(owner) == DialogResult.OK;
        }
    }

    public static void ShowCode(IWin32Window owner, string code)
    {
        using (Form f = Base("Look megosztása", 500))
        {
            Label l = AddText(f, "A kód a vágólapra került. Küldd el bárkinek (Discord, üzenet), ő a „Beillesztés” gombbal tudja betölteni ugyanezt a beállítást.", 18);
            TextBox tb = AddBox(f, code, l.Bottom + 10, true, true);
            Button copy = UI.MakeButton("Másolás újra", 0, 0, 140, 32, true);
            copy.Click += delegate { try { Clipboard.SetText(code); } catch (Exception) { } };
            Button close = UI.MakeButton("Bezár", 0, 0, 100, 32, false); close.DialogResult = DialogResult.OK;
            Finish(f, tb.Bottom + 16, copy, close);
            f.AcceptButton = close; f.CancelButton = close;
            f.Shown += delegate { tb.SelectAll(); };
            f.ShowDialog(owner);
        }
    }
}

// ================= Fo ablak =================
public class Param
{
    public string Key, Title;
    public int Min, Max, Def, Step;
    public bool Bi;
}

public class MainForm : Form
{
    const int VIB = 0, SAT = 1, BRI = 2, CON = 3, HI = 4, BL = 5, SHT = 6, GAM = 7, TMP = 8, SH = 9, WH = 10, HIT = 11;
    const string RunKey = @"Software\Microsoft\Windows\CurrentVersion\Run";
    const string RunName = "GammaVezerlo";

    Param[] P;
    Slider[] S;
    bool nvOk, bypass, loading, exiting, cleaned, allowVisible, balloonShown;
    System.Windows.Forms.Timer debounce;
    DarkList list;
    Button btnCompare, btnAuto, btnFineReset, btnSave, btnShare, btnImport, btnDel, btnExit;
    Card cardTop, cardFine, cardScn;
    NotifyIcon ni;
    ContextMenuStrip menu;
    ToolStripMenuItem miBypass, miAuto, miScenes;
    HotKeyWindow hk;
    string dataDir, profDir, stateFile;
    List<string> presetNames = new List<string>();
    List<Dictionary<string, int>> presetVals = new List<Dictionary<string, int>>();

    public MainForm(bool startHidden)
    {
        allowVisible = !startHidden;
        nvOk = Nv.Init();
        int nvDef = nvOk ? Nv.DefaultPercent : 50;

        P = new Param[LookCode.N];
        for (int i = 0; i < LookCode.N; i++)
        {
            Param p = new Param();
            p.Key = LookCode.Keys[i]; p.Title = LookCode.Titles[i];
            p.Min = LookCode.Mins[i]; p.Max = LookCode.Maxs[i];
            p.Def = LookCode.Defs[i]; p.Step = LookCode.Steps[i]; p.Bi = LookCode.Bi[i];
            P[i] = p;
        }
        P[VIB].Def = nvDef;
        S = new Slider[LookCode.N];

        dataDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "GammaVezerlo");
        profDir = Path.Combine(dataDir, "profilok");
        stateFile = Path.Combine(dataDir, "allapot.json");
        try { Directory.CreateDirectory(profDir); } catch (Exception) { }
        MigrateOld();
        AddPresets();

        debounce = new System.Windows.Forms.Timer();
        debounce.Interval = 30;
        debounce.Tick += delegate { debounce.Stop(); ApplyNow(); };

        BuildUi();
        BuildTray();

        try
        {
            if (File.Exists(stateFile)) { loading = true; SetValues(ReadLook(stateFile)); loading = false; }
        }
        catch (Exception) { loading = false; }
        RefreshList(null);
        RefreshLabels();
        ApplyNow();

        hk = new HotKeyWindow();
        hk.Register(1, 3, 0x47);   // Ctrl+Alt+G
        hk.Register(2, 3, 0x26);   // Ctrl+Alt+Fel
        hk.Register(3, 3, 0x28);   // Ctrl+Alt+Le
        hk.Register(4, 3, 0x4F);   // Ctrl+Alt+O
        hk.Pressed += OnHotKey;
    }

    // ---------- fajlok ----------
    void MigrateOld()
    {
        try
        {
            string exeDir = Path.GetDirectoryName(Application.ExecutablePath);
            string oldProf = Path.Combine(exeDir, "profilok");
            if (Directory.Exists(oldProf))
                foreach (string f in Directory.GetFiles(oldProf, "*.json"))
                {
                    string dst = Path.Combine(profDir, Path.GetFileName(f));
                    if (!File.Exists(dst)) File.Copy(f, dst);
                }
            string oldState = Path.Combine(exeDir, "allapot.json");
            if (!File.Exists(stateFile) && File.Exists(oldState)) File.Copy(oldState, stateFile);
        }
        catch (Exception) { }
    }

    Dictionary<string, int> ReadLook(string path)
    {
        return LookCode.FromJson(File.ReadAllText(path, Encoding.UTF8));
    }

    void WriteLook(string path, int[] v)
    {
        File.WriteAllText(path, LookCode.ToJson(v), new UTF8Encoding(false));
    }

    string LookPath(string name) { return Path.Combine(profDir, name + ".json"); }

    void SaveState()
    {
        try { WriteLook(stateFile, GetValues()); } catch (Exception) { }
    }

    // ---------- jelenetek ----------
    void AddPreset(string name, params object[] kv)
    {
        Dictionary<string, int> d = new Dictionary<string, int>();
        for (int i = 0; i + 1 < kv.Length; i += 2) d[(string)kv[i]] = (int)kv[i + 1];
        presetNames.Add(name);
        presetVals.Add(d);
    }

    void AddPresets()
    {
        AddPreset("Kiegyensúlyozott");
        AddPreset("Élénk", "vib", 100, "sat", 140, "con", 104);
        AddPreset("Erdő", "vib", 100, "sat", 230, "bri", 104, "gam", 112, "con", 98, "tmp", -14);
        AddPreset("Sivatag", "vib", 100, "sat", 160, "con", 106, "tmp", 12, "hi", -15, "sh", 15);
        AddPreset("Hó", "vib", 100, "sat", 130, "con", 108, "hi", -25, "wh", -10, "sh", 15, "tmp", -10);
        AddPreset("Sötét pályák", "bri", 108, "gam", 125, "sh", 40, "bl", 10, "sat", 115);
        AddPreset("Éles (FPS)", "vib", 100, "sat", 150, "con", 112, "sh", 30, "bl", -10, "gam", 108);
    }

    // ---------- ertekek ----------
    int[] Defaults()
    {
        int[] v = new int[LookCode.N];
        for (int i = 0; i < v.Length; i++) v[i] = P[i].Def;
        return v;
    }

    int[] GetValues()
    {
        int[] v = new int[LookCode.N];
        for (int i = 0; i < v.Length; i++) v[i] = S[i].Value;
        return v;
    }

    void SetValues(Dictionary<string, int> d)
    {
        int[] v = Defaults();
        foreach (KeyValuePair<string, int> kv in d)
        {
            int i = LookCode.IndexOf(kv.Key);
            if (i >= 0) v[i] = kv.Value;
        }
        SetValues(v);
    }

    void SetValues(int[] v)
    {
        bool old = loading;
        loading = true;
        for (int i = 0; i < v.Length && i < S.Length; i++) S[i].Value = v[i];
        loading = old;
    }

    static string Fmt(int idx, int v)
    {
        switch (idx)
        {
            case GAM: return (v / 100.0).ToString("0.00", CultureInfo.InvariantCulture);
            case BRI:
            case CON: return v.ToString(CultureInfo.InvariantCulture) + "%";
            default: return v.ToString(CultureInfo.InvariantCulture);
        }
    }

    void RefreshLabels()
    {
        for (int i = 0; i < S.Length; i++)
        {
            if (S[i] == null) continue;
            S[i].ValueText = Fmt(i, S[i].Value);
            S[i].Invalidate();
        }
    }

    // ---------- hatas alkalmazasa ----------
    static float[] BuildMatrix(double sat, double bri, double con, double tmp)
    {
        double[] lum = { 0.2126, 0.7152, 0.0722 };
        double w = tmp / 100.0;
        double[] t = w >= 0 ? new double[] { 1.0, 1.0 - 0.10 * w, 1.0 - 0.35 * w }
                            : new double[] { 1.0 + 0.35 * w, 1.0 + 0.10 * w, 1.0 };
        float[] m = new float[25];
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
            {
                double s = (1.0 - sat) * lum[i];
                if (i == j) s += sat;
                double k = bri * t[j];
                m[i * 5 + j] = (float)(con * k * s);
            }
        for (int j = 0; j < 3; j++)
        {
            double k = bri * t[j];
            m[4 * 5 + j] = (float)(k * 0.5 * (1.0 - con));
        }
        m[3 * 5 + 3] = 1f;
        m[4 * 5 + 4] = 1f;
        return m;
    }

    void ApplyNow()
    {
        int[] v = bypass ? Defaults() : GetValues();
        int vib = v[VIB];
        int nvPct = Math.Min(100, vib);
        double extra = 1.0;
        if (vib > 100) extra = 1.0 + (vib - 100) / 100.0;
        if (nvOk) Nv.SetPercent(nvPct);
        else extra = 0.5 + vib / 100.0;   // NVIDIA nelkul: teljesen szoftveres (50 = semleges)
        double sat = (v[SAT] / 100.0) * extra;

        GammaRamp.ApplyCurves(v[GAM] / 100.0, v[HI] / 100.0, v[SH] / 100.0, v[BL] / 100.0, v[WH] / 100.0, v[SHT] / 100.0, v[HIT] / 100.0);
        Mag.Set(BuildMatrix(sat, v[BRI] / 100.0, v[CON] / 100.0, v[TMP]));

        if (btnCompare != null)
        {
            if (bypass) { btnCompare.Text = "● Eredeti kép"; btnCompare.BackColor = Theme.Accent; }
            else { btnCompare.Text = "Összehasonlítás"; btnCompare.BackColor = Theme.Card2; }
        }
    }

    // ---------- felulet ----------
    Slider MakeSlider(int idx, Control parent, int x, int y, int w, bool big)
    {
        Param p = P[idx];
        Slider s = new Slider();
        s.Minimum = p.Min; s.Maximum = p.Max; s.DefaultValue = p.Def; s.Step = p.Step;
        s.Caption = p.Title; s.Big = big; s.FillFromDefault = p.Bi;
        s.Location = new Point(x, y);
        s.Size = new Size(w, big ? 112 : 48);
        s.Value = p.Def;
        s.ValueChanged += OnSliderChanged;
        parent.Controls.Add(s);
        S[idx] = s;
        return s;
    }

    void OnSliderChanged(object sender, EventArgs e)
    {
        RefreshLabels();
        if (!loading) { debounce.Stop(); debounce.Start(); }
    }

    void BuildUi()
    {
        Text = "Gamma Vezérlő";
        ClientSize = new Size(960, 686);
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        BackColor = Theme.Bg;
        ForeColor = Theme.Text;
        Font = new Font("Segoe UI", 9.5f);
        TopMost = true;
        Icon = UI.LoadIcon(new Size(32, 32));

        Font dim = Font;
        Controls.Add(UI.MakeLabel("Kijelző", 16, 2, new Font("Segoe UI Light", 24f), Theme.Text));
        Controls.Add(UI.MakeLabel("A csúszkák minden játékban működnek. Dupla kattintás egy csúszkán: alapérték.", 18, 55, dim, Theme.Dim));

        btnCompare = UI.MakeButton("Összehasonlítás", 796, 20, 148, 34, false);
        btnCompare.Click += delegate { ToggleBypass(); };
        Controls.Add(btnCompare);

        string st = "Élő  ·  " + Nv.Status;
        int sw = TextRenderer.MeasureText(st, dim).Width;
        Label lblStatus = UI.MakeLabel(st, 780 - sw, 27, dim, Theme.Dim);
        Label lblDot = UI.MakeLabel("●", 780 - sw - 18, 27, dim, Color.FromArgb(60, 200, 110));
        Controls.Add(lblDot); Controls.Add(lblStatus);

        cardTop = new Card(); cardTop.Location = new Point(16, 78); cardTop.Size = new Size(928, 136);
        cardFine = new Card(); cardFine.Title = "Finomhangolás"; cardFine.Location = new Point(16, 226); cardFine.Size = new Size(590, 404);
        cardScn = new Card(); cardScn.Title = "Jelenetek"; cardScn.Location = new Point(618, 226); cardScn.Size = new Size(326, 404);
        Controls.Add(cardTop); Controls.Add(cardFine); Controls.Add(cardScn);

        Slider sv = MakeSlider(VIB, cardTop, 24, 12, 424, true);
        sv.Unit = "%"; sv.Hint = "100 fölött szoftveres";
        sv.MarkValues = new int[] { 0, 100, 350 }; sv.MarkTexts = new string[] { "0", "100 · driver", "350" };
        Slider ss = MakeSlider(SAT, cardTop, 480, 12, 424, true);
        ss.Unit = "%"; ss.Hint = "100 = az eredeti kép";
        ss.MarkValues = new int[] { 0, 100, 200, 300 }; ss.MarkTexts = new string[] { "0", "100", "200", "300" };

        int[] col1 = { BRI, CON, HI, BL, SHT };
        int[] col2 = { GAM, TMP, SH, WH, HIT };
        for (int r = 0; r < 5; r++)
        {
            MakeSlider(col1[r], cardFine, 22, 56 + r * 66, 262, false);
            MakeSlider(col2[r], cardFine, 308, 56 + r * 66, 262, false);
        }

        btnFineReset = UI.MakeButton("Alaphelyzet", 462, 10, 108, 30, false);
        btnFineReset.Click += delegate
        {
            loading = true;
            int[] fine = { BRI, CON, HI, BL, SHT, GAM, TMP, SH, WH, HIT };
            foreach (int k in fine) S[k].Value = P[k].Def;
            loading = false;
            RefreshLabels(); ApplyNow();
        };
        cardFine.Controls.Add(btnFineReset);

        btnSave = UI.MakeButton("Look mentése", 188, 10, 124, 30, false);
        btnSave.Click += delegate { SaveCurrentLook(); };
        cardScn.Controls.Add(btnSave);

        list = new DarkList();
        list.ItemHeight = 32;
        list.Location = new Point(14, 56);
        list.Size = new Size(298, 256);
        list.SelectedIndexChanged += OnListChanged;
        cardScn.Controls.Add(list);

        btnShare = UI.MakeButton("Kód másolása", 14, 324, 145, 32, false);
        btnShare.Click += delegate { ShareCurrent(); };
        btnImport = UI.MakeButton("Beillesztés", 167, 324, 145, 32, false);
        btnImport.Click += delegate { ImportCode(); };
        btnDel = UI.MakeButton("Kiválasztott törlése", 14, 362, 298, 32, false);
        btnDel.Click += delegate { DeleteSelected(); };
        cardScn.Controls.Add(btnShare); cardScn.Controls.Add(btnImport); cardScn.Controls.Add(btnDel);

        Controls.Add(UI.MakeLabel("Ctrl+Alt+G ablak   ·   Ctrl+Alt+↑/↓ vibrance   ·   Ctrl+Alt+O eredeti kép", 18, 650, dim, Theme.Dim));
        btnAuto = UI.MakeButton("", 590, 642, 236, 32, false);
        btnAuto.Click += delegate { ToggleAutostart(); };
        Controls.Add(btnAuto);
        UpdateAutoButton();
        btnExit = UI.MakeButton("Kilépés", 844, 642, 100, 32, false);
        btnExit.Click += delegate { DoExit(); };
        Controls.Add(btnExit);
    }

    // ---------- lista, look-ok ----------
    void RefreshList(string select)
    {
        bool old = loading;
        loading = true;
        list.Items.Clear();
        foreach (string n in presetNames) list.Items.Add(n);
        list.BuiltIn = presetNames.Count;
        try
        {
            string[] files = Directory.GetFiles(profDir, "*.json");
            Array.Sort(files, StringComparer.CurrentCultureIgnoreCase);
            foreach (string f in files) list.Items.Add(Path.GetFileNameWithoutExtension(f));
        }
        catch (Exception) { }
        if (select != null && list.Items.Contains(select)) list.SelectedItem = select;
        else list.SelectedIndex = -1;
        loading = old;
    }

    string SelectedName()
    {
        return list.SelectedIndex >= 0 ? list.Items[list.SelectedIndex].ToString() : null;
    }

    void OnListChanged(object sender, EventArgs e)
    {
        if (loading) return;
        int i = list.SelectedIndex;
        if (i < 0) return;
        ApplyLookAt(i);
    }

    void ApplyLookAt(int i)
    {
        Dictionary<string, int> d;
        if (i < presetNames.Count) d = presetVals[i];
        else
        {
            try { d = ReadLook(LookPath(list.Items[i].ToString())); }
            catch (Exception) { return; }
        }
        SetValues(d);
        RefreshLabels();
        ApplyNow();
    }

    void SelectLook(string name)
    {
        int i = list.Items.IndexOf(name);
        if (i >= 0) list.SelectedIndex = i;
    }

    string UniqueName(string name)
    {
        string baseName = LookCode.SafeName(name);
        if (baseName.Length == 0) baseName = "saját";
        string n = baseName; int k = 2;
        while (presetNames.Contains(n) || File.Exists(LookPath(n))) { n = baseName + " (" + k + ")"; k++; }
        return n;
    }

    void SaveCurrentLook()
    {
        string sel = SelectedName();
        string sug = (sel != null && list.SelectedIndex >= presetNames.Count) ? sel : "saját";
        string name = Dlg.Prompt(this, "Look mentése", "A look neve:", sug, false, "Mentés");
        if (string.IsNullOrEmpty(name)) return;
        name = LookCode.SafeName(name);
        if (name.Length == 0) return;
        if (presetNames.Contains(name)) name = name + " (saját)";
        try { WriteLook(LookPath(name), GetValues()); }
        catch (Exception ex) { Dlg.Info(this, "Hiba", "Nem sikerült menteni: " + ex.Message); return; }
        RefreshList(name);
    }

    void DeleteSelected()
    {
        int i = list.SelectedIndex;
        if (i < 0) return;
        if (i < presetNames.Count)
        {
            Dlg.Info(this, "Gamma Vezérlő", "A beépített jeleneteket nem lehet törölni.");
            return;
        }
        string name = list.Items[i].ToString();
        if (!Dlg.Confirm(this, "Törlés", "Biztosan törlöd ezt a lookot: „" + name + "”?", "Törlés")) return;
        try { File.Delete(LookPath(name)); } catch (Exception) { }
        RefreshList(null);
    }

    void ShareCurrent()
    {
        string name = SelectedName();
        if (name == null) name = "Saját look";
        string code = LookCode.Encode(name, GetValues());
        try { Clipboard.SetText(code); } catch (Exception) { }
        Dlg.ShowCode(this, code);
    }

    void ImportCode()
    {
        string clip = "";
        try { if (Clipboard.ContainsText()) clip = Clipboard.GetText(); } catch (Exception) { }
        string pre = LookCode.HasCode(clip) ? clip.Trim() : "";
        string txt = Dlg.Prompt(this, "Look beillesztése", "Illeszd be a kapott kódot (GV1-…):", pre, true, "Betöltés");
        if (txt == null) return;
        string name; int[] v;
        if (!LookCode.Decode(txt, out name, out v))
        {
            Dlg.Info(this, "Érvénytelen kód", "A kód nem olvasható vagy sérült. Másold ki újra, teljes egészében (GV1-től a végéig).");
            return;
        }
        SetValues(v);
        RefreshLabels();
        ApplyNow();
        string save = Dlg.Prompt(this, "Look mentése", "Betöltve. Mentsd el ezen a néven, vagy Mégse, ha csak kipróbálnád:", name, false, "Mentés");
        if (!string.IsNullOrEmpty(save))
        {
            string unique = UniqueName(save);
            try { WriteLook(LookPath(unique), v); RefreshList(unique); }
            catch (Exception ex) { Dlg.Info(this, "Hiba", "Nem sikerült menteni: " + ex.Message); }
        }
    }

    // ---------- tálca ----------
    ToolStripMenuItem MakeItem(string text, EventHandler h)
    {
        ToolStripMenuItem m = new ToolStripMenuItem(text);
        m.ForeColor = Theme.Text;
        m.Font = Font;
        if (h != null) m.Click += h;
        return m;
    }

    void BuildTray()
    {
        menu = new ContextMenuStrip();
        menu.Renderer = new ToolStripProfessionalRenderer(new DarkColors());
        menu.BackColor = Theme.Card;
        menu.ForeColor = Theme.Text;
        menu.Font = Font;
        ToolStripMenuItem miOpen = MakeItem("Megnyitás", delegate { ShowWindow(); });
        miOpen.Font = new Font(Font, FontStyle.Bold);
        miBypass = MakeItem("Eredeti kép (összehasonlítás)", delegate { ToggleBypass(); });
        miScenes = MakeItem("Jelenetek", null);
        miScenes.DropDown.Renderer = menu.Renderer;
        miScenes.DropDown.BackColor = Theme.Card;
        miAuto = MakeItem("Indítás Windowsszal", delegate { ToggleAutostart(); });
        ToolStripMenuItem miExit = MakeItem("Kilépés", delegate { DoExit(); });
        menu.Items.AddRange(new ToolStripItem[] { miOpen, miBypass, miScenes, new ToolStripSeparator(), miAuto, new ToolStripSeparator(), miExit });
        menu.Opening += delegate { RefreshTrayMenu(); };

        ni = new NotifyIcon();
        ni.Icon = UI.LoadIcon(SystemInformation.SmallIconSize);
        ni.Text = "Gamma Vezérlő";
        ni.ContextMenuStrip = menu;
        ni.Visible = true;
        ni.MouseDoubleClick += delegate(object s, MouseEventArgs e) { if (e.Button == MouseButtons.Left) ToggleWindow(); };
    }

    void RefreshTrayMenu()
    {
        miBypass.Checked = bypass;
        miAuto.Checked = GetAutostart();
        miScenes.DropDownItems.Clear();
        for (int i = 0; i < list.Items.Count; i++)
        {
            string name = list.Items[i].ToString();
            ToolStripMenuItem it = MakeItem(name, delegate { SelectLook(name); });
            it.Checked = (list.SelectedIndex == i);
            miScenes.DropDownItems.Add(it);
        }
    }

    // ---------- inditas Windowsszal ----------
    static bool GetAutostart()
    {
        try
        {
            using (RegistryKey k = Registry.CurrentUser.OpenSubKey(RunKey, false))
                return k != null && k.GetValue(RunName) != null;
        }
        catch (Exception) { return false; }
    }

    static void SetAutostart(bool on)
    {
        try
        {
            using (RegistryKey k = Registry.CurrentUser.OpenSubKey(RunKey, true))
            {
                if (k == null) return;
                if (on) k.SetValue(RunName, "\"" + Application.ExecutablePath + "\" --tray");
                else k.DeleteValue(RunName, false);
            }
        }
        catch (Exception) { }
    }

    void ToggleAutostart() { SetAutostart(!GetAutostart()); UpdateAutoButton(); }

    void UpdateAutoButton()
    {
        btnAuto.Text = "Indítás Windowsszal: " + (GetAutostart() ? "BE" : "KI");
    }

    // ---------- ablak / kilepes ----------
    void ToggleBypass() { bypass = !bypass; ApplyNow(); }

    public void ShowWindow()
    {
        allowVisible = true;
        if (!Visible) Show();
        if (WindowState == FormWindowState.Minimized) WindowState = FormWindowState.Normal;
        Activate();
        BringToFront();
    }

    void ToggleWindow()
    {
        if (Visible) Hide(); else ShowWindow();
    }

    void OnHotKey(int id)
    {
        switch (id)
        {
            case 1: ToggleWindow(); break;
            case 2: S[VIB].Value += 5; break;
            case 3: S[VIB].Value -= 5; break;
            case 4: ToggleBypass(); break;
        }
    }

    protected override void SetVisibleCore(bool value)
    {
        if (!allowVisible)
        {
            value = false;
            if (!IsHandleCreated) CreateHandle();
        }
        base.SetVisibleCore(value);
    }

    protected override void OnHandleCreated(EventArgs e)
    {
        base.OnHandleCreated(e);
        Theme.DarkTitle(Handle);
    }

    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        if (!exiting && e.CloseReason == CloseReason.UserClosing)
        {
            e.Cancel = true;
            Hide();
            if (!balloonShown)
            {
                balloonShown = true;
                ni.ShowBalloonTip(2500, "Gamma Vezérlő", "A program a tálcán fut tovább. Kilépés: jobb klikk az ikonra.", ToolTipIcon.Info);
            }
            return;
        }
        base.OnFormClosing(e);
        CleanupOnce();
    }

    void DoExit()
    {
        exiting = true;
        Close();
    }

    void CleanupOnce()
    {
        if (cleaned) return;
        cleaned = true;
        SaveState();
        try { if (hk != null) hk.Dispose(); } catch (Exception) { }
        try { ni.Visible = false; ni.Dispose(); } catch (Exception) { }
        EmergencyRestore();
    }

    public static void EmergencyRestore()
    {
        try { GammaRamp.ApplyCurves(1.0, 0, 0, 0, 0, 0, 0); } catch (Exception) { }
        try { Nv.Restore(); } catch (Exception) { }
        try { Mag.Shutdown(); } catch (Exception) { }
    }
}

// ================= Belepesi pont =================
public static class Program
{
    static void LogError(Exception ex)
    {
        try
        {
            string dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "GammaVezerlo");
            Directory.CreateDirectory(dir);
            File.AppendAllText(Path.Combine(dir, "hiba.log"), DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "  " + (ex == null ? "?" : ex.ToString()) + "\r\n\r\n");
        }
        catch (Exception) { }
    }

    [STAThread]
    static void Main(string[] args)
    {
        bool created;
        Mutex mutex = new Mutex(true, "Local\\GammaVezerlo_Single", out created);
        if (!created)
        {
            // mar fut egy peldany: azt hozzuk elo
            try { EventWaitHandle.OpenExisting("Local\\GammaVezerlo_Show").Set(); } catch (Exception) { }
            return;
        }
        EventWaitHandle showEvent = new EventWaitHandle(false, EventResetMode.AutoReset, "Local\\GammaVezerlo_Show");

        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
        Application.ThreadException += delegate(object s, ThreadExceptionEventArgs e) { LogError(e.Exception); };
        AppDomain.CurrentDomain.UnhandledException += delegate(object s, UnhandledExceptionEventArgs e)
        {
            LogError(e.ExceptionObject as Exception);
            MainForm.EmergencyRestore();
        };
        AppDomain.CurrentDomain.ProcessExit += delegate { MainForm.EmergencyRestore(); };

        bool tray = Array.IndexOf(args, "--tray") >= 0;
        MainForm form = new MainForm(tray);

        Thread waiter = new Thread(delegate()
        {
            while (true)
            {
                showEvent.WaitOne();
                try { if (form.IsHandleCreated) form.BeginInvoke(new MethodInvoker(form.ShowWindow)); }
                catch (Exception) { }
            }
        });
        waiter.IsBackground = true;
        waiter.Start();

        Application.Run(form);
        try { mutex.ReleaseMutex(); } catch (Exception) { }
    }
}
