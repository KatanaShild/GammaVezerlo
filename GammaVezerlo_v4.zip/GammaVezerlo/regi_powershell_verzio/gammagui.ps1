﻿# Gamma Vezerlo v3  -  fekete/piros felulet, teljes finomhangolas
#  - NVIDIA Digital Vibrance (NVAPI, driver-szint, 0-100%)
#  - Magnification API 5x5 szinmatrix (szaturacio, fenyero, kontraszt, homerseklet, vibrance 100% felett)
#  - Gamma-gorbe (SetDeviceGammaRamp): gamma, fenyek, arnyekok, feketek, fehérek, arnyek/feny arnyalat
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName Microsoft.VisualBasic
[System.Windows.Forms.Application]::EnableVisualStyles()

$cs = @"
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Runtime.InteropServices;
using System.Windows.Forms;

// ---------------- Gamma-gorbe (minden aktiv monitorra) ----------------
public static class GammaRamp
{
    [StructLayout(LayoutKind.Sequential)]
    public struct RAMP
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 256)] public ushort[] Red;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 256)] public ushort[] Green;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 256)] public ushort[] Blue;
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    public struct DISPLAY_DEVICE
    {
        public uint cb;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string DeviceName;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string DeviceString;
        public uint StateFlags;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string DeviceID;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string DeviceKey;
    }
    [DllImport("user32.dll")] static extern bool EnumDisplayDevices(string lpDevice, uint iDevNum, ref DISPLAY_DEVICE lpDisplayDevice, uint dwFlags);
    [DllImport("gdi32.dll", CharSet = CharSet.Ansi)] static extern IntPtr CreateDC(string lpszDriver, string lpszDevice, string lpszOutput, IntPtr lpInitData);
    [DllImport("gdi32.dll")] static extern bool DeleteDC(IntPtr hdc);
    [DllImport("gdi32.dll")] static extern bool SetDeviceGammaRamp(IntPtr hdc, ref RAMP lpRamp);

    // Parameterek: gam (1.0 = semleges), a tobbi -1..1
    // Az arnyalat (tint): pozitiv = meleg (piros+), negativ = hideg (kek+)
    public static ushort[][] BuildCurves(double gam, double hi, double sh, double bl, double wh, double shT, double hiT)
    {
        ushort[][] ch = new ushort[3][];
        for (int c = 0; c < 3; c++) ch[c] = new ushort[256];
        double[] prev = new double[3];
        for (int i = 0; i < 256; i++)
        {
            double x = i / 255.0;
            double xg = Math.Pow(x, 1.0 / Math.Max(0.1, gam));
            double mS = 6.75 * xg * (1 - xg) * (1 - xg);   // arnyek-maszk (csucs ~1/3-nal)
            double mH = 6.75 * xg * xg * (1 - xg);         // feny-maszk  (csucs ~2/3-nal)
            double y = xg;
            y += 0.30 * sh * mS + 0.30 * hi * mH;
            y += 0.15 * bl * Math.Pow(1 - xg, 3) + 0.15 * wh * xg * xg * xg;
            double tint = 0.08 * shT * (1 - xg) * (1 - xg) + 0.08 * hiT * xg * xg;
            double[] v = new double[] { y + tint, y, y - tint };
            for (int c = 0; c < 3; c++)
            {
                double val = Math.Max(0.0, Math.Min(1.0, v[c]));
                if (val < prev[c]) val = prev[c];          // monoton novekvo
                prev[c] = val;
                double u = val * 65535.0;
                // a Windows elutasitja a linearistol tul tavoli gorbeket -> korlatozzuk
                double lo = Math.Max(0.0, i * 257.0 - 120 * 256.0);
                double hiL = Math.Min(65535.0, i * 257.0 + 120 * 256.0);
                u = Math.Max(lo, Math.Min(hiL, u));
                ch[c][i] = (ushort)Math.Round(u);
            }
        }
        return ch;
    }

    public static void ApplyCurves(double gam, double hi, double sh, double bl, double wh, double shT, double hiT)
    {
        ushort[][] c = BuildCurves(gam, hi, sh, bl, wh, shT, hiT);
        RAMP ramp = new RAMP();
        ramp.Red = c[0]; ramp.Green = c[1]; ramp.Blue = c[2];
        uint i = 0;
        while (true)
        {
            DISPLAY_DEVICE dev = new DISPLAY_DEVICE();
            dev.cb = (uint)Marshal.SizeOf(dev);
            if (!EnumDisplayDevices(null, i, ref dev, 0)) break;
            if ((dev.StateFlags & 1) != 0)
            {
                IntPtr hdc = CreateDC("DISPLAY", dev.DeviceName, null, IntPtr.Zero);
                if (hdc != IntPtr.Zero) { SetDeviceGammaRamp(hdc, ref ramp); DeleteDC(hdc); }
            }
            i++;
        }
    }
}

// ---------------- Windows Magnification: fullscreen 5x5 szinmatrix ----------------
public static class Mag
{
    [StructLayout(LayoutKind.Sequential)]
    public struct MAGCOLOREFFECT
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 25)] public float[] transform;
    }
    [DllImport("Magnification.dll")] static extern bool MagInitialize();
    [DllImport("Magnification.dll")] static extern bool MagUninitialize();
    [DllImport("Magnification.dll")] static extern bool MagSetFullscreenColorEffect(ref MAGCOLOREFFECT e);

    static bool inited = false;
    public static string Status = "nincs inicializalva";

    public static bool Set(float[] m)
    {
        try
        {
            if (!inited) { inited = MagInitialize(); }
            if (!inited) { Status = "MagInitialize sikertelen"; return false; }
            MAGCOLOREFFECT e = new MAGCOLOREFFECT();
            e.transform = m;
            bool ok = MagSetFullscreenColorEffect(ref e);
            Status = ok ? "OK" : "MagSetFullscreenColorEffect sikertelen";
            return ok;
        }
        catch (Exception ex) { Status = ex.Message; return false; }
    }
    public static void Shutdown()
    {
        try
        {
            if (inited)
            {
                float[] id = new float[] { 1,0,0,0,0, 0,1,0,0,0, 0,0,1,0,0, 0,0,0,1,0, 0,0,0,0,1 };
                Set(id);
                MagUninitialize();
                inited = false;
            }
        }
        catch (Exception) { }
    }
}

// ---------------- NVIDIA NVAPI: Digital Vibrance ----------------
public static class Nv
{
    [DllImport("nvapi64.dll", EntryPoint = "nvapi_QueryInterface", CallingConvention = CallingConvention.Cdecl)]
    static extern IntPtr QI64(uint id);
    [DllImport("nvapi.dll", EntryPoint = "nvapi_QueryInterface", CallingConvention = CallingConvention.Cdecl)]
    static extern IntPtr QI32(uint id);
    static IntPtr QI(uint id) { return IntPtr.Size == 8 ? QI64(id) : QI32(id); }

    [StructLayout(LayoutKind.Sequential)]
    public struct DVC { public uint version; public int current; public int min; public int max; public int def; }

    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int D_Init();
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int D_Enum(uint idx, out IntPtr h);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int D_Get3(IntPtr h, uint outId, ref DVC i);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int D_Get2(IntPtr h, ref DVC i);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int D_Set3(IntPtr h, uint outId, ref DVC i);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int D_Set2(IntPtr h, ref DVC i);

    static T Fn<T>(uint id) where T : class
    {
        IntPtr p = QI(id);
        if (p == IntPtr.Zero) return null;
        return (T)(object)Marshal.GetDelegateForFunctionPointer(p, typeof(T));
    }

    const uint ID_Init = 0x0150E828, ID_Enum = 0x9ABDD40D, ID_GetEx = 0x0E45002D, ID_SetEx = 0x4A82C2B1;
    const uint VER = 20 | (1u << 16);

    static List<IntPtr> handles = new List<IntPtr>();
    static List<DVC> infos = new List<DVC>();
    static D_Set3 set3; static D_Set2 set2; static int setMode = 0;
    public static string Status = "nincs inicializalva";
    public static bool Available = false;
    public static int Count { get { return handles.Count; } }
    public static int DefaultPercent = 50;

    public static bool Init()
    {
        try
        {
            D_Init init = Fn<D_Init>(ID_Init);
            if (init == null) { Status = "NVAPI nem található"; return false; }
            int r = init();
            if (r != 0) { Status = "NvAPI_Initialize hiba: " + r; return false; }
            D_Enum en = Fn<D_Enum>(ID_Enum);
            D_Get3 get3 = Fn<D_Get3>(ID_GetEx);
            D_Get2 get2 = Fn<D_Get2>(ID_GetEx);
            set3 = Fn<D_Set3>(ID_SetEx);
            set2 = Fn<D_Set2>(ID_SetEx);
            if (en == null || get3 == null) { Status = "NVAPI fuggvenyek hianyoznak"; return false; }
            int enumCount = 0, lastErr = 0;
            for (uint i = 0; i < 16; i++)
            {
                IntPtr h;
                if (en(i, out h) != 0) break;
                enumCount++;
                DVC info = new DVC(); info.version = VER;
                int gr = get3(h, 0, ref info);
                if (gr != 0) { info = new DVC(); info.version = VER; gr = get2(h, ref info); }
                if (gr == 0) { handles.Add(h); infos.Add(info); } else { lastErr = gr; }
            }
            if (handles.Count == 0)
            {
                Status = (enumCount == 0)
                    ? "NVIDIA kijelző nem található · szoftveres vibrance"
                    : "NVIDIA vibrance nem elérhető (kód: " + lastErr + ") · szoftveres";
                return false;
            }
            DVC f = infos[0];
            if (f.max > f.min) DefaultPercent = (int)Math.Round((f.def - f.min) * 100.0 / (f.max - f.min));
            Available = true;
            Status = "NVIDIA driver OK (" + handles.Count + " kijelző)";
            return true;
        }
        catch (DllNotFoundException) { Status = "Nincs NVIDIA driver · szoftveres vibrance"; return false; }
        catch (Exception ex) { Status = ex.Message; return false; }
    }

    static bool SetLevel(int idx, int level)
    {
        DVC info = infos[idx]; info.current = level; info.version = VER;
        IntPtr h = handles[idx];
        if (setMode != 2 && set3 != null)
        {
            if (set3(h, 0, ref info) == 0) { setMode = 3; return true; }
        }
        if (setMode != 3 && set2 != null)
        {
            if (set2(h, ref info) == 0) { setMode = 2; return true; }
        }
        return false;
    }

    public static bool SetPercent(int pct)
    {
        if (!Available) return false;
        if (pct < 0) pct = 0;
        if (pct > 100) pct = 100;
        bool any = false;
        for (int i = 0; i < handles.Count; i++)
        {
            DVC f = infos[i];
            int lvl = f.min + (int)Math.Round(pct / 100.0 * (f.max - f.min));
            if (SetLevel(i, lvl)) any = true;
        }
        return any;
    }

    public static void Restore()
    {
        if (!Available) return;
        for (int i = 0; i < handles.Count; i++) SetLevel(i, infos[i].current);
    }
}

// ---------------- Globalis hotkey ----------------
public class HotKeyWindow : NativeWindow, IDisposable
{
    [DllImport("user32.dll")] static extern bool RegisterHotKey(IntPtr hWnd, int id, uint mods, uint vk);
    [DllImport("user32.dll")] static extern bool UnregisterHotKey(IntPtr hWnd, int id);
    public event Action<int> Pressed;
    public HotKeyWindow() { CreateHandle(new CreateParams()); }
    public bool Register(int id, uint mods, uint vk) { return RegisterHotKey(Handle, id, mods, vk); }
    protected override void WndProc(ref Message m)
    {
        if (m.Msg == 0x0312 && Pressed != null) Pressed(m.WParam.ToInt32());
        base.WndProc(ref m);
    }
    public void Dispose()
    {
        for (int i = 1; i <= 16; i++) UnregisterHotKey(Handle, i);
        DestroyHandle();
    }
}

// ---------------- Tema + sajat kontrollok (fekete / piros) ----------------
public static class Theme
{
    public static readonly Color Bg      = Color.FromArgb(10, 10, 12);
    public static readonly Color Card    = Color.FromArgb(20, 20, 23);
    public static readonly Color Card2   = Color.FromArgb(30, 30, 34);
    public static readonly Color Border  = Color.FromArgb(40, 40, 45);
    public static readonly Color Text    = Color.FromArgb(242, 242, 244);
    public static readonly Color Dim     = Color.FromArgb(135, 135, 143);
    public static readonly Color Accent  = Color.FromArgb(229, 32, 46);
    public static readonly Color AccentD = Color.FromArgb(150, 20, 30);
    public static readonly Color Track   = Color.FromArgb(44, 44, 50);

    [DllImport("dwmapi.dll")] static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int val, int size);
    public static void DarkTitle(IntPtr h)
    {
        try { int v = 1; if (DwmSetWindowAttribute(h, 20, ref v, 4) != 0) DwmSetWindowAttribute(h, 19, ref v, 4); }
        catch (Exception) { }
    }
}

public class Card : Panel
{
    public string Title = "";
    static Font fTitle = new Font("Segoe UI Semibold", 11f);
    public Card()
    {
        SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        BackColor = Theme.Card;
    }
    protected override void OnPaint(PaintEventArgs e)
    {
        Graphics g = e.Graphics;
        g.Clear(Theme.Bg);
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
        Rectangle r = new Rectangle(0, 0, Width - 1, Height - 1);
        int d = 24;
        using (GraphicsPath p = new GraphicsPath())
        {
            p.AddArc(r.X, r.Y, d, d, 180, 90);
            p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            p.CloseFigure();
            using (SolidBrush b = new SolidBrush(Theme.Card)) g.FillPath(b, p);
            using (Pen pen = new Pen(Theme.Border)) g.DrawPath(pen, p);
        }
        if (Title.Length > 0)
            using (SolidBrush tb = new SolidBrush(Theme.Text)) g.DrawString(Title, fTitle, tb, 20, 16);
    }
}

public class Slider : Control
{
    public int Minimum = 0, Maximum = 100, DefaultValue = 0, Step = 1;
    public string Caption = "", ValueText = "", Hint = "", Unit = "";
    public bool Big = false, FillFromDefault = false;
    public int[] MarkValues = null;
    public string[] MarkTexts = null;
    public event EventHandler ValueChanged;
    int val = 0; bool drag = false, hover = false;

    static Font fCap = new Font("Segoe UI", 9.5f);
    static Font fVal = new Font("Segoe UI Semibold", 9.5f);
    static Font fCapBig = new Font("Segoe UI Semibold", 11f);
    static Font fBig = new Font("Segoe UI Light", 27f);
    static Font fUnit = new Font("Segoe UI", 12f);
    static Font fSmall = new Font("Segoe UI", 8f);

    public Slider()
    {
        SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        BackColor = Theme.Card;
        Cursor = Cursors.Hand;
    }

    public int Value
    {
        get { return val; }
        set
        {
            int v = Math.Max(Minimum, Math.Min(Maximum, value));
            if (v == val) return;
            val = v; Invalidate();
            if (ValueChanged != null) ValueChanged(this, EventArgs.Empty);
        }
    }

    float TrackY { get { return Big ? 82f : 38f; } }
    float PosX(int v) { float pad = 10f; return pad + (float)(v - Minimum) / (Maximum - Minimum) * (Width - 2 * pad); }
    int FromX(int x) { float pad = 10f; double t = (x - pad) / (Width - 2 * pad); return (int)Math.Round(Minimum + t * (Maximum - Minimum)); }

    protected override void OnPaint(PaintEventArgs e)
    {
        Graphics g = e.Graphics;
        g.Clear(BackColor);
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
        float ty = TrackY;
        using (SolidBrush white = new SolidBrush(Theme.Text))
        using (SolidBrush dim = new SolidBrush(Theme.Dim))
        {
            if (Big)
            {
                g.DrawString(Caption, fCapBig, white, 0, 0);
                SizeF hs = g.MeasureString(Hint, fSmall);
                g.DrawString(Hint, fSmall, dim, Width - hs.Width, 4);
                g.DrawString(ValueText, fBig, white, -3, 16);
                SizeF vs = g.MeasureString(ValueText, fBig);
                g.DrawString(Unit, fUnit, dim, vs.Width - 12, 40);
            }
            else
            {
                g.DrawString(Caption, fCap, dim, 0, 2);
                SizeF vs2 = g.MeasureString(ValueText, fVal);
                g.DrawString(ValueText, fVal, white, Width - vs2.Width + 2, 2);
            }
        }
        float x0 = PosX(FillFromDefault ? DefaultValue : Minimum);
        float x1 = PosX(val);
        using (Pen tp = new Pen(Theme.Track, 4f)) { tp.StartCap = LineCap.Round; tp.EndCap = LineCap.Round; g.DrawLine(tp, PosX(Minimum), ty, PosX(Maximum), ty); }
        if (Math.Abs(x1 - x0) > 0.5f)
            using (Pen fp = new Pen(Theme.Accent, 4f)) { fp.StartCap = LineCap.Round; fp.EndCap = LineCap.Round; g.DrawLine(fp, x0, ty, x1, ty); }
        // jelolok
        using (Pen mp = new Pen(Color.FromArgb(90, 90, 98), 1f))
        {
            if (MarkValues != null)
                for (int i = 0; i < MarkValues.Length; i++) { float mx = PosX(MarkValues[i]); g.DrawLine(mp, mx, ty - 7, mx, ty + 7); }
            else if (FillFromDefault)
            { float mx2 = PosX(DefaultValue); g.DrawLine(mp, mx2, ty - 7, mx2, ty + 7); }
        }
        if (Big && MarkTexts != null && MarkValues != null)
        {
            using (SolidBrush dim2 = new SolidBrush(Theme.Dim))
                for (int i = 0; i < MarkTexts.Length; i++)
                {
                    SizeF ms = g.MeasureString(MarkTexts[i], fSmall);
                    float mx = PosX(MarkValues[i]) - ms.Width / 2;
                    if (i == 0) mx = 2; else if (i == MarkTexts.Length - 1) mx = Width - ms.Width;
                    g.DrawString(MarkTexts[i], fSmall, dim2, mx, ty + 12);
                }
        }
        // fogantyu
        float tx = x1;
        if (drag || hover)
            using (SolidBrush ring = new SolidBrush(Color.FromArgb(70, Theme.Accent))) g.FillEllipse(ring, tx - 12, ty - 12, 24, 24);
        using (SolidBrush tb = new SolidBrush(Color.White)) g.FillEllipse(tb, tx - 8, ty - 8, 16, 16);
        using (Pen op = new Pen(drag ? Theme.Accent : Theme.AccentD, 2f)) g.DrawEllipse(op, tx - 8, ty - 8, 16, 16);
    }

    protected override void OnMouseDown(MouseEventArgs e) { if (e.Button == MouseButtons.Left) { drag = true; Capture = true; Value = FromX(e.X); Invalidate(); } base.OnMouseDown(e); }
    protected override void OnMouseMove(MouseEventArgs e) { if (drag) Value = FromX(e.X); base.OnMouseMove(e); }
    protected override void OnMouseUp(MouseEventArgs e) { drag = false; Capture = false; Invalidate(); base.OnMouseUp(e); }
    protected override void OnMouseEnter(EventArgs e) { hover = true; Invalidate(); base.OnMouseEnter(e); }
    protected override void OnMouseLeave(EventArgs e) { hover = false; Invalidate(); base.OnMouseLeave(e); }
    protected override void OnMouseDoubleClick(MouseEventArgs e) { Value = DefaultValue; base.OnMouseDoubleClick(e); }
    protected override void OnMouseWheel(MouseEventArgs e) { Value = val + (e.Delta > 0 ? Step : -Step); }
}

public class DarkList : ListBox
{
    public int BuiltIn = 0;
    static Font f = new Font("Segoe UI", 10.5f);
    public DarkList()
    {
        DrawMode = DrawMode.OwnerDrawFixed;
        ItemHeight = 36;
        BorderStyle = BorderStyle.None;
        BackColor = Theme.Card;
        ForeColor = Theme.Text;
        SetStyle(ControlStyles.OptimizedDoubleBuffer, true);
    }
    protected override void OnDrawItem(DrawItemEventArgs e)
    {
        if (e.Index < 0) return;
        bool sel = (e.State & DrawItemState.Selected) != 0;
        using (SolidBrush b = new SolidBrush(sel ? Color.FromArgb(38, 16, 20) : Theme.Card)) e.Graphics.FillRectangle(b, e.Bounds);
        if (sel) using (SolidBrush a = new SolidBrush(Theme.Accent)) e.Graphics.FillRectangle(a, e.Bounds.X, e.Bounds.Y + 4, 3, e.Bounds.Height - 8);
        if (e.Index == BuiltIn && BuiltIn > 0)
            using (Pen p = new Pen(Theme.Border)) e.Graphics.DrawLine(p, e.Bounds.X + 8, e.Bounds.Y, e.Bounds.Right - 8, e.Bounds.Y);
        Rectangle tr = new Rectangle(e.Bounds.X + 14, e.Bounds.Y, e.Bounds.Width - 14, e.Bounds.Height);
        TextRenderer.DrawText(e.Graphics, Items[e.Index].ToString(), f, tr, sel ? Theme.Text : Color.FromArgb(200, 200, 205), TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.EndEllipsis);
    }
}
"@
Add-Type -TypeDefinition $cs -ReferencedAssemblies System.Windows.Forms, System.Drawing

# ---------------- Alkalmazas logika ----------------
$script:bypass = $false
$script:loading = $false
$nvOk = [Nv]::Init()
$nvDef = if ($nvOk) { [Nv]::DefaultPercent } else { 50 }

# K=kulcs, T=felirat, Bi=ketiranyu (kozeprol tolt), St=gorgo lepes
$defs = @(
    @{ K='vib'; T='Vibrance';               Min=0;   Max=350; Def=$nvDef; Bi=$false; St=5 },
    @{ K='sat'; T='Szaturáció';             Min=0;   Max=300; Def=100;    Bi=$false; St=5 },
    @{ K='bri'; T='Fényerő';                Min=20;  Max=150; Def=100;    Bi=$true;  St=1 },
    @{ K='con'; T='Kontraszt';              Min=50;  Max=200; Def=100;    Bi=$true;  St=1 },
    @{ K='hi';  T='Fények';                 Min=-100; Max=100; Def=0;     Bi=$true;  St=2 },
    @{ K='bl';  T='Feketék';                Min=-100; Max=100; Def=0;     Bi=$true;  St=2 },
    @{ K='sht'; T='Árnyék árnyalat';        Min=-100; Max=100; Def=0;     Bi=$true;  St=2 },
    @{ K='gam'; T='Gamma';                  Min=50;  Max=250; Def=100;    Bi=$true;  St=1 },
    @{ K='tmp'; T='Hőmérséklet';            Min=-100; Max=100; Def=0;     Bi=$true;  St=2 },
    @{ K='sh';  T='Árnyékok';               Min=-100; Max=100; Def=0;     Bi=$true;  St=2 },
    @{ K='wh';  T='Fehérek';                Min=-100; Max=100; Def=0;     Bi=$true;  St=2 },
    @{ K='hit'; T='Fény árnyalat';          Min=-100; Max=100; Def=0;     Bi=$true;  St=2 }
)
$fineKeys = @('bri','con','hi','bl','sht','gam','tmp','sh','wh','hit')

# Beepitett jelenetek (amit nem ad meg, az alapertek)
$presets = [ordered]@{
    'Kiegyensúlyozott' = @{}
    'Élénk'            = @{ vib=100; sat=140; con=104 }
    'Erdő'             = @{ vib=100; sat=230; bri=104; gam=112; con=98; tmp=-14 }
    'Sivatag'          = @{ vib=100; sat=160; con=106; tmp=12; hi=-15; sh=15 }
    'Hó'               = @{ vib=100; sat=130; con=108; hi=-25; wh=-10; sh=15; tmp=-10 }
    'Sötét pályák'     = @{ bri=108; gam=125; sh=40; bl=10; sat=115 }
    'Éles (FPS)'       = @{ vib=100; sat=150; con=112; sh=30; bl=-10; gam=108 }
}

function Format-Value([string]$k, [int]$v) {
    switch ($k) {
        'vib' { return "$v" }
        'sat' { return "$v" }
        'bri' { return "$v%" }
        'con' { return "$v%" }
        'gam' { return ($v / 100.0).ToString('0.00', [Globalization.CultureInfo]::InvariantCulture) }
        default { return "$v" }
    }
}

function Build-Matrix([double]$sat, [double]$bri, [double]$con, [double]$tmp) {
    # Magnification: sor-vektor konvencio, out_j = sum_i in_i * M[i][j], 5. sor = eltolas
    $lum = @(0.2126, 0.7152, 0.0722)
    $w = $tmp / 100.0
    if ($w -ge 0) { $t = @(1.0, (1.0 - 0.10 * $w), (1.0 - 0.35 * $w)) }
    else          { $t = @((1.0 + 0.35 * $w), (1.0 + 0.10 * $w), 1.0) }
    $m = New-Object 'single[]' 25
    for ($i = 0; $i -lt 3; $i++) {
        for ($j = 0; $j -lt 3; $j++) {
            $s = (1.0 - $sat) * $lum[$i]
            if ($i -eq $j) { $s += $sat }
            $k = $bri * $t[$j]
            $m[$i * 5 + $j] = [single]($con * $k * $s)
        }
    }
    for ($j = 0; $j -lt 3; $j++) {
        $k = $bri * $t[$j]
        $m[4 * 5 + $j] = [single]($k * 0.5 * (1.0 - $con))
    }
    $m[3 * 5 + 3] = 1.0
    $m[4 * 5 + 4] = 1.0
    return $m
}

function Get-DefaultValues {
    $h = @{}
    foreach ($d in $defs) { $h[$d.K] = $d.Def }
    return $h
}

function Apply-Settings($v) {
    if ($script:bypass) { $v = Get-DefaultValues }
    # Vibrance: 0-100 driver, 100 folott extra szoftveres szaturacio
    $vib = [int]$v.vib
    $nvPct = [Math]::Min(100, $vib)
    $extra = 1.0
    if ($vib -gt 100) { $extra = 1.0 + ($vib - 100) / 100.0 }
    if ($nvOk) { [void][Nv]::SetPercent($nvPct) }
    else { $extra = 0.5 + $vib / 100.0 }   # NVIDIA nelkul: teljesen szoftveres (50 = semleges)
    $sat = ($v.sat / 100.0) * $extra

    [GammaRamp]::ApplyCurves(($v.gam / 100.0), ($v.hi / 100.0), ($v.sh / 100.0), ($v.bl / 100.0), ($v.wh / 100.0), ($v.sht / 100.0), ($v.hit / 100.0))
    [void][Mag]::Set((Build-Matrix $sat ($v.bri / 100.0) ($v.con / 100.0) $v.tmp))

    if ($btnCompare) {
        if ($script:bypass) { $btnCompare.Text = '● Eredeti kép'; $btnCompare.BackColor = [Theme]::Accent }
        else { $btnCompare.Text = 'Összehasonlítás'; $btnCompare.BackColor = [Theme]::Card2 }
    }
}

# ---------------- Mappak / fajlok ----------------
$baseDir = $PSScriptRoot
if (-not $baseDir) { $baseDir = Split-Path -Parent $MyInvocation.MyCommand.Path }
$profDir = Join-Path $baseDir 'profilok'
if (-not (Test-Path $profDir)) { New-Item -ItemType Directory -Path $profDir | Out-Null }
$stateFile = Join-Path $baseDir 'allapot.json'

# ---------------- GUI ----------------
$fontUI = New-Object System.Drawing.Font('Segoe UI', 9.5)

function New-Button([string]$text, [int]$x, [int]$y, [int]$w, [int]$h, [bool]$primary = $false) {
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $text
    $b.Location = New-Object System.Drawing.Point($x, $y)
    $b.Size = New-Object System.Drawing.Size($w, $h)
    $b.FlatStyle = 'Flat'
    $b.UseVisualStyleBackColor = $false
    $b.Cursor = 'Hand'
    $b.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 9.5)
    $b.ForeColor = [Theme]::Text
    $b.FlatAppearance.BorderSize = 1
    if ($primary) {
        $b.BackColor = [Theme]::Accent
        $b.FlatAppearance.BorderColor = [Theme]::Accent
        $b.FlatAppearance.MouseOverBackColor = [System.Drawing.Color]::FromArgb(245, 60, 72)
    } else {
        $b.BackColor = [Theme]::Card2
        $b.FlatAppearance.BorderColor = [Theme]::Border
        $b.FlatAppearance.MouseOverBackColor = [System.Drawing.Color]::FromArgb(48, 48, 54)
    }
    return $b
}

function New-Label([string]$text, [int]$x, [int]$y, [System.Drawing.Font]$font, [System.Drawing.Color]$color) {
    $l = New-Object System.Windows.Forms.Label
    $l.Text = $text; $l.AutoSize = $true
    $l.Location = New-Object System.Drawing.Point($x, $y)
    $l.Font = $font; $l.ForeColor = $color; $l.BackColor = [System.Drawing.Color]::Transparent
    return $l
}

$form = New-Object System.Windows.Forms.Form
$form.Text = 'Gamma Vezérlő'
$form.ClientSize = New-Object System.Drawing.Size(960, 686)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedSingle'
$form.MaximizeBox = $false
$form.BackColor = [Theme]::Bg
$form.ForeColor = [Theme]::Text
$form.Font = $fontUI
$form.Topmost = $true
try { $form.Icon = New-Object System.Drawing.Icon (Join-Path $baseDir 'gammagui.ico') } catch { }
$form.Add_Shown({ [Theme]::DarkTitle($form.Handle) })

# fejlec
$form.Controls.Add((New-Label 'Kijelző' 16 2 (New-Object System.Drawing.Font('Segoe UI Light', 24)) ([Theme]::Text)))
$form.Controls.Add((New-Label 'A csúszkák minden játékban működnek. Dupla kattintás egy csúszkán: alapérték.' 18 55 $fontUI ([Theme]::Dim)))
$btnCompare = New-Button 'Összehasonlítás' 796 20 148 34
$form.Controls.Add($btnCompare)
$lblStatus = New-Label ('Élő  ·  ' + [Nv]::Status) 0 27 $fontUI ([Theme]::Dim)
$lblStatus.Location = New-Object System.Drawing.Point((780 - $lblStatus.PreferredWidth), 27)
$lblDot = New-Label '●' ($lblStatus.Left - 18) 27 $fontUI ([System.Drawing.Color]::FromArgb(60, 200, 110))
$form.Controls.AddRange(@($lblDot, $lblStatus))

# felso kartya: vibrance + szaturacio
$cardTop = New-Object Card
$cardTop.Location = New-Object System.Drawing.Point(16, 78)
$cardTop.Size = New-Object System.Drawing.Size(928, 136)
$form.Controls.Add($cardTop)

# finomhangolas kartya
$cardFine = New-Object Card
$cardFine.Title = 'Finomhangolás'
$cardFine.Location = New-Object System.Drawing.Point(16, 226)
$cardFine.Size = New-Object System.Drawing.Size(590, 404)
$form.Controls.Add($cardFine)

# jelenetek kartya
$cardScn = New-Object Card
$cardScn.Title = 'Jelenetek'
$cardScn.Location = New-Object System.Drawing.Point(618, 226)
$cardScn.Size = New-Object System.Drawing.Size(326, 404)
$form.Controls.Add($cardScn)

$sliders = @{}
function New-Slider($d, $parent, [int]$x, [int]$y, [int]$w, [bool]$big) {
    $s = New-Object Slider
    $s.Minimum = $d.Min; $s.Maximum = $d.Max; $s.DefaultValue = $d.Def; $s.Step = $d.St
    $s.Caption = $d.T; $s.Big = $big; $s.FillFromDefault = $d.Bi; $s.Tag = $d.K
    $s.Location = New-Object System.Drawing.Point($x, $y)
    $s.Size = New-Object System.Drawing.Size($w, $(if ($big) { 112 } else { 48 }))
    $s.Value = $d.Def
    $parent.Controls.Add($s)
    $sliders[$d.K] = $s
    return $s
}

$dv = $defs | Where-Object { $_.K -eq 'vib' }
$ds = $defs | Where-Object { $_.K -eq 'sat' }
$sv = New-Slider $dv $cardTop 24 12 424 $true
$sv.Unit = '%'; $sv.Hint = '100 fölött szoftveres'
$sv.MarkValues = [int[]]@(0, 100, 350); $sv.MarkTexts = [string[]]@('0', '100 · driver', '350')
$ss = New-Slider $ds $cardTop 480 12 424 $true
$ss.Unit = '%'; $ss.Hint = '100 = az eredeti kép'
$ss.MarkValues = [int[]]@(0, 100, 200, 300); $ss.MarkTexts = [string[]]@('0', '100', '200', '300')

# finomhangolas: 2 oszlop x 5 sor
$col1 = @('bri', 'con', 'hi', 'bl', 'sht')
$col2 = @('gam', 'tmp', 'sh', 'wh', 'hit')
for ($r = 0; $r -lt 5; $r++) {
    $d1 = $defs | Where-Object { $_.K -eq $col1[$r] }
    $d2 = $defs | Where-Object { $_.K -eq $col2[$r] }
    [void](New-Slider $d1 $cardFine 22 (56 + $r * 66) 262 $false)
    [void](New-Slider $d2 $cardFine 308 (56 + $r * 66) 262 $false)
}

function Get-Values {
    $h = @{}
    foreach ($d in $defs) { $h[$d.K] = $sliders[$d.K].Value }
    return $h
}

function Set-Values($h) {
    foreach ($d in $defs) {
        if ($h.ContainsKey($d.K)) {
            $sliders[$d.K].Value = [int]$h[$d.K]
        }
    }
}

function Refresh-Labels {
    foreach ($d in $defs) {
        $sl = $sliders[$d.K]
        $sl.ValueText = Format-Value $d.K $sl.Value
        $sl.Invalidate()
    }
}

# debounce: huzas kozben ne fusson minden pixelnel
$debounce = New-Object System.Windows.Forms.Timer
$debounce.Interval = 30
$debounce.Add_Tick({
    $debounce.Stop()
    Apply-Settings (Get-Values)
})
foreach ($d in $defs) {
    $sliders[$d.K].add_ValueChanged({
        Refresh-Labels
        if (-not $script:loading) { $debounce.Stop(); $debounce.Start() }
    })
}

# gombok
$btnFineReset = New-Button 'Alaphelyzet' 462 10 108 30
$cardFine.Controls.Add($btnFineReset)
$btnSave = New-Button 'Look mentése' 188 10 124 30
$cardScn.Controls.Add($btnSave)

$list = New-Object DarkList
$list.Location = New-Object System.Drawing.Point(14, 56)
$list.Size = New-Object System.Drawing.Size(298, 288)
$cardScn.Controls.Add($list)
$btnDel = New-Button 'Kiválasztott törlése' 14 358 298 32
$cardScn.Controls.Add($btnDel)

$lblKeys = New-Label 'Ctrl+Alt+G ablak   ·   Ctrl+Alt+↑/↓ vibrance   ·   Ctrl+Alt+O eredeti kép' 18 648 $fontUI ([Theme]::Dim)
$form.Controls.Add($lblKeys)
$btnExit = New-Button 'Kilépés' 844 642 100 32
$form.Controls.Add($btnExit)

$script:userNames = @()
function Refresh-Profiles([string]$select = '') {
    $script:loading = $true
    $list.Items.Clear()
    foreach ($n in $presets.Keys) { [void]$list.Items.Add($n) }
    $list.BuiltIn = $presets.Count
    $script:userNames = @()
    Get-ChildItem -Path $profDir -Filter *.json -ErrorAction SilentlyContinue | ForEach-Object {
        $script:userNames += $_.BaseName
        [void]$list.Items.Add($_.BaseName)
    }
    if ($select -and $list.Items.Contains($select)) { $list.SelectedItem = $select }
    else { $list.SelectedIndex = -1 }
    $script:loading = $false
}

function Read-JsonHash([string]$path) {
    $o = Get-Content -Raw -Path $path | ConvertFrom-Json
    $h = @{}
    $o.PSObject.Properties | ForEach-Object { $h[$_.Name] = $_.Value }
    return $h
}

$list.Add_SelectedIndexChanged({
    if ($script:loading) { return }
    $i = $list.SelectedIndex
    if ($i -lt 0) { return }
    $name = [string]$list.Items[$i]
    $vals = Get-DefaultValues
    if ($i -lt $presets.Count) {
        foreach ($k in $presets[$name].Keys) { $vals[$k] = $presets[$name][$k] }
    } else {
        $f = Join-Path $profDir ($name + '.json')
        if (Test-Path $f) { $h = Read-JsonHash $f; foreach ($k in $h.Keys) { $vals[$k] = $h[$k] } }
    }
    $script:loading = $true
    Set-Values $vals
    $script:loading = $false
    Refresh-Labels
    Apply-Settings (Get-Values)
})

$btnFineReset.Add_Click({
    $script:loading = $true
    foreach ($k in $fineKeys) { $sliders[$k].Value = $sliders[$k].DefaultValue }
    $script:loading = $false
    Refresh-Labels
    Apply-Settings (Get-Values)
})

$btnCompare.Add_Click({
    $script:bypass = -not $script:bypass
    Apply-Settings (Get-Values)
})

$btnSave.Add_Click({
    $form.Topmost = $false
    $name = [Microsoft.VisualBasic.Interaction]::InputBox('A look neve:', 'Look mentése', 'sajat')
    $form.Topmost = $true
    $form.Activate()
    if ($name) {
        $name = ($name -replace '[\\/:*?"<>|]', '_')
        if ($presets.Contains($name)) { $name = $name + ' (saját)' }
        (Get-Values | ConvertTo-Json) | Set-Content -Path (Join-Path $profDir ($name + '.json')) -Encoding UTF8
        Refresh-Profiles $name
    }
})

$btnDel.Add_Click({
    $i = $list.SelectedIndex
    if ($i -ge $presets.Count) {
        $f = Join-Path $profDir ($list.Items[$i] + '.json')
        if (Test-Path $f) { Remove-Item $f }
        Refresh-Profiles
    } elseif ($i -ge 0) {
        [void][System.Windows.Forms.MessageBox]::Show('A beépített jeleneteket nem lehet törölni.', 'Gamma Vezérlő')
    }
})

# ---------------- Indulas: utolso allapot ----------------
if (Test-Path $stateFile) {
    try {
        $script:loading = $true
        Set-Values (Read-JsonHash $stateFile)
        $script:loading = $false
    } catch { $script:loading = $false }
}
Refresh-Profiles
Refresh-Labels
Apply-Settings (Get-Values)

# ---------------- Globalis hotkey-k ----------------
$hk = New-Object HotKeyWindow
[void]$hk.Register(1, 3, 0x47)   # Ctrl+Alt+G   ablak
[void]$hk.Register(2, 3, 0x26)   # Ctrl+Alt+Fel vibrance +5
[void]$hk.Register(3, 3, 0x28)   # Ctrl+Alt+Le  vibrance -5
[void]$hk.Register(4, 3, 0x4F)   # Ctrl+Alt+O   eredeti kep ki/be
$hk.add_Pressed([Action[int]]{
    param($id)
    switch ($id) {
        1 { if ($form.Visible) { $form.Hide() } else { $form.Show(); $form.Activate() } }
        2 { $t = $sliders['vib']; $t.Value = $t.Value + 5 }
        3 { $t = $sliders['vib']; $t.Value = $t.Value - 5 }
        4 { $script:bypass = -not $script:bypass; Apply-Settings (Get-Values) }
    }
})

# ---------------- Kilepes: allapot mentese + minden visszaallitasa ----------------
$form.Add_FormClosing({
    (Get-Values | ConvertTo-Json) | Set-Content -Path $stateFile -Encoding UTF8
    $hk.Dispose()
    [GammaRamp]::ApplyCurves(1.0, 0, 0, 0, 0, 0, 0)
    [Nv]::Restore()
    [Mag]::Shutdown()
})
$btnExit.Add_Click({ $form.Close() })

[void]$form.ShowDialog()
